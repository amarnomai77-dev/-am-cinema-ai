/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Real Client-Side Video Compositor & Exporter
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import { Shot, CinemaProject } from '../types/cinema';

export interface RenderProgressUpdate {
  percent: number;
  currentShot: number;
  totalShots: number;
  statusText: string;
}

export class VideoCompositor {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private width: number;
  private height: number;
  private isCancelled: boolean = false;

  constructor(width = 1280, height = 720) {
    this.width = width;
    this.height = height;
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    const context = this.canvas.getContext('2d');
    if (!context) {
      throw new Error('Could not create 2D canvas context');
    }
    this.ctx = context;
  }

  public cancel() {
    this.isCancelled = true;
  }

  /**
   * Preload an image URL into an HTMLImageElement
   */
  private loadImage(url: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => {
        // Fallback: draw placeholder on failure instead of breaking render
        const fallbackCanvas = document.createElement('canvas');
        fallbackCanvas.width = this.width;
        fallbackCanvas.height = this.height;
        const fctx = fallbackCanvas.getContext('2d')!;
        fctx.fillStyle = '#111116';
        fctx.fillRect(0, 0, this.width, this.height);
        fctx.fillStyle = '#f59e0b';
        fctx.font = 'bold 36px Cairo, sans-serif';
        fctx.textAlign = 'center';
        fctx.fillText('AM CINEMA AI — KEYFRAME', this.width / 2, this.height / 2);
        const fallbackImg = new Image();
        fallbackImg.onload = () => resolve(fallbackImg);
        fallbackImg.src = fallbackCanvas.toDataURL();
      };
      img.src = url;
    });
  }

  /**
   * Render a complete project into a downloadable video
   */
  public async renderProjectToVideo(
    project: CinemaProject,
    onProgress?: (update: RenderProgressUpdate) => void
  ): Promise<string> {
    this.isCancelled = false;

    // Collect all shots across scenes
    const allShots: Shot[] = [];
    for (const scene of project.scenes) {
      for (const shot of scene.shots) {
        allShots.push(shot);
      }
    }

    if (allShots.length === 0) {
      throw new Error('Project has no shots to render');
    }

    // Preload image assets
    onProgress?.({
      percent: 5,
      currentShot: 0,
      totalShots: allShots.length,
      statusText: 'Preloading cinematic keyframes and textures...',
    });

    const loadedImages: HTMLImageElement[] = [];
    for (let i = 0; i < allShots.length; i++) {
      const shot = allShots[i];
      const imgUrl = shot.imageUrl || `https://image.pollinations.ai/prompt/${encodeURIComponent(shot.visualPrompt)}?width=1280&height=720&seed=101&nologo=true`;
      try {
        const img = await this.loadImage(imgUrl);
        loadedImages.push(img);
      } catch (e) {
        console.warn('Image load failed for shot', shot.id, e);
      }
    }

    // Set up Audio Context and media stream
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const dest = audioCtx.createMediaStreamDestination();

    // Create subtle ambient background drone in audio track
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(55, audioCtx.currentTime); // Low A1 note
    gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
    osc.connect(gain);
    gain.connect(dest);
    osc.start();

    // Capture Canvas stream at 30 fps
    const canvasStream = this.canvas.captureStream(30);
    const audioTrack = dest.stream.getAudioTracks()[0];
    if (audioTrack) {
      canvasStream.addTrack(audioTrack);
    }

    let mimeType = 'video/webm;codecs=vp9,opus';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm';
    }

    const mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType,
      videoBitsPerSecond: 4000000, // 4 Mbps high bitrate
    });

    const recordedChunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    const recordingPromise = new Promise<string>((resolve, reject) => {
      mediaRecorder.onstop = () => {
        osc.stop();
        audioCtx.close().catch(() => {});
        const finalBlob = new Blob(recordedChunks, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(finalBlob);
        resolve(videoUrl);
      };
      mediaRecorder.onerror = (err) => reject(err);
    });

    mediaRecorder.start();

    const fps = 30;
    let totalFramesRendered = 0;
    const totalDurationSeconds = allShots.reduce((acc, s) => acc + (s.durationSeconds || 4), 0);
    const estimatedTotalFrames = totalDurationSeconds * fps;

    // Render shot by shot
    for (let shotIndex = 0; shotIndex < allShots.length; shotIndex++) {
      if (this.isCancelled) {
        mediaRecorder.stop();
        throw new Error('Video rendering cancelled by user');
      }

      const shot = allShots[shotIndex];
      const shotImg = loadedImages[shotIndex];
      const shotDuration = shot.durationSeconds || 4;
      const shotFrames = shotDuration * fps;

      for (let frame = 0; frame < shotFrames; frame++) {
        if (this.isCancelled) break;

        const progressInShot = frame / shotFrames; // 0.0 to 1.0
        this.renderSingleFrame(
          shot,
          shotImg,
          progressInShot,
          project,
          shotIndex,
          allShots.length
        );

        totalFramesRendered++;
        const percent = Math.min(95, Math.round((totalFramesRendered / estimatedTotalFrames) * 90) + 5);

        if (frame % 10 === 0) {
          onProgress?.({
            percent,
            currentShot: shotIndex + 1,
            totalShots: allShots.length,
            statusText: `Compositing Shot ${shotIndex + 1}/${allShots.length} (${shot.cameraMovement})`,
          });
          // Allow event loop breathing room
          await new Promise((r) => setTimeout(r, 8));
        }
      }
    }

    // Stop recorder & finalize video
    onProgress?.({
      percent: 98,
      currentShot: allShots.length,
      totalShots: allShots.length,
      statusText: 'Encoding final cinema master file...',
    });

    mediaRecorder.stop();
    const finalUrl = await recordingPromise;

    onProgress?.({
      percent: 100,
      currentShot: allShots.length,
      totalShots: allShots.length,
      statusText: 'Film export ready!',
    });

    return finalUrl;
  }

  /**
   * Render single frame with dynamic Ken Burns camera movement, letterboxing & watermark
   */
  private renderSingleFrame(
    shot: Shot,
    img: HTMLImageElement | undefined,
    progress: number,
    project: CinemaProject,
    shotIndex: number,
    totalShots: number
  ) {
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;

    // Clear background
    ctx.fillStyle = '#050507';
    ctx.fillRect(0, 0, w, h);

    if (img) {
      ctx.save();

      // Camera Movement Matrix calculations
      let scale = 1.0;
      let offsetX = 0;
      let offsetY = 0;

      const strength = (shot.motionStrength || 5) / 10; // 0.1 to 1.0

      switch (shot.cameraMovement) {
        case 'zoom_in':
          scale = 1.0 + progress * (0.22 * strength);
          break;
        case 'zoom_out':
          scale = 1.22 - progress * (0.22 * strength);
          break;
        case 'pan_left':
          scale = 1.15;
          offsetX = -progress * (100 * strength);
          break;
        case 'pan_right':
          scale = 1.15;
          offsetX = progress * (100 * strength);
          break;
        case 'tilt_up':
          scale = 1.15;
          offsetY = -progress * (70 * strength);
          break;
        case 'tilt_down':
          scale = 1.15;
          offsetY = progress * (70 * strength);
          break;
        case 'camera_tracking':
        case 'orbit_360':
        case 'crane_shot':
          scale = 1.08 + Math.sin(progress * Math.PI) * (0.15 * strength);
          offsetX = Math.cos(progress * Math.PI) * (40 * strength);
          break;
        default:
          scale = 1.04;
          break;
      }

      // Draw transformed image centered
      ctx.translate(w / 2 + offsetX, h / 2 + offsetY);
      ctx.scale(scale, scale);
      ctx.drawImage(img, -w / 2, -h / 2, w, h);
      ctx.restore();
    }

    // Transition overlay (Fade to black / Crossfade)
    if (progress > 0.88 && shot.transitionToNext === 'fade_black') {
      const alpha = (progress - 0.88) / 0.12;
      ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
      ctx.fillRect(0, 0, w, h);
    } else if (progress < 0.12 && shotIndex > 0) {
      const alpha = 1.0 - progress / 0.12;
      ctx.fillStyle = `rgba(0, 0, 0, ${alpha * 0.7})`;
      ctx.fillRect(0, 0, w, h);
    }

    // Cinemascope Letterbox (2.39:1 aspect ratio bars)
    if (project.settings.aspectRatio === '2.39:1') {
      const barHeight = Math.round(h * 0.12);
      ctx.fillStyle = '#050507';
      ctx.fillRect(0, 0, w, barHeight);
      ctx.fillRect(0, h - barHeight, w, barHeight);

      // Gold framing line
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)';
      ctx.lineWidth = 1;
      ctx.strokeRect(0, barHeight, w, h - barHeight * 2);
    }

    // Cinematic subtitles / dialogue display
    if (shot.dialogue && shot.dialogue.textAr) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      const subBoxH = 50;
      ctx.fillRect(w * 0.15, h - 85, w * 0.7, subBoxH);

      ctx.fillStyle = '#fbbf24';
      ctx.font = '600 22px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(shot.dialogue.textAr, w / 2, h - 52);
    }

    // Subtle luxury brand watermark in top corner
    ctx.fillStyle = 'rgba(245, 158, 11, 0.75)';
    ctx.font = '600 13px Cinzel, Cairo, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('AM CINEMA AI', 24, 30);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.font = '400 11px Cairo, sans-serif';
    ctx.fillText('DIRECTED BY AMMAR ALNAMI', 24, 46);
  }
}
