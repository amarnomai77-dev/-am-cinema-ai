/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Diagnostics & Test Runner
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

export interface DiagnosticResult {
  id: string;
  name: string;
  nameAr: string;
  category: 'api' | 'canvas' | 'audio' | 'consistency' | 'storage';
  status: 'passed' | 'failed' | 'running';
  durationMs: number;
  message: string;
  messageAr: string;
  details?: string;
}

export async function runCinemaDiagnostics(): Promise<DiagnosticResult[]> {
  const results: DiagnosticResult[] = [];

  // Test 1: Server Health & Gemini Gateway Check
  const t1Start = performance.now();
  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    if (res.ok && data.status === 'online') {
      results.push({
        id: 'test_health',
        name: 'Server & AI Gateway Connection',
        nameAr: 'اتصال الخادم وبوابة الذكاء الاصطناعي',
        category: 'api',
        status: 'passed',
        durationMs: Math.round(performance.now() - t1Start),
        message: `Connected successfully to AM CINEMA AI server. Gemini Key present: ${data.hasGeminiKey ? 'YES' : 'NO'}.`,
        messageAr: `تم الاتصال بالخادم بنجاح. حالة مفتاح Gemini: ${data.hasGeminiKey ? 'نشط' : 'غير متصل (يعمل على المحركات المفتوحة)'}`,
      });
    } else {
      throw new Error(`Status ${res.status}`);
    }
  } catch (err: any) {
    results.push({
      id: 'test_health',
      name: 'Server & AI Gateway Connection',
      nameAr: 'اتصال الخادم وبوابة الذكاء الاصطناعي',
      category: 'api',
      status: 'failed',
      durationMs: Math.round(performance.now() - t1Start),
      message: `Failed to connect: ${err.message}`,
      messageAr: `تعذر الاتصال بالخادم: ${err.message}`,
    });
  }

  // Test 2: HTML5 Canvas Compositor & WebGL/2D Support
  const t2Start = performance.now();
  try {
    const testCanvas = document.createElement('canvas');
    testCanvas.width = 1280;
    testCanvas.height = 720;
    const ctx = testCanvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context unsupported');
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(0, 0, 100, 100);
    const hasCapture = typeof testCanvas.captureStream === 'function';
    const hasMediaRecorder = typeof window.MediaRecorder !== 'undefined';

    if (hasCapture && hasMediaRecorder) {
      results.push({
        id: 'test_canvas',
        name: 'Video Compositor & MediaRecorder Engine',
        nameAr: 'محرك دمج الفيديو وMediaRecorder',
        category: 'canvas',
        status: 'passed',
        durationMs: Math.round(performance.now() - t2Start),
        message: 'Canvas stream capture and MediaRecorder supported at 30/60fps.',
        messageAr: 'دعم كامل لالتقاط إطارات الكانفاس وتسجيل الفيديو بمعدل 30/60 إطار في الثانية.',
      });
    } else {
      results.push({
        id: 'test_canvas',
        name: 'Video Compositor & MediaRecorder Engine',
        nameAr: 'محرك دمج الفيديو وMediaRecorder',
        category: 'canvas',
        status: 'failed',
        durationMs: Math.round(performance.now() - t2Start),
        message: 'MediaRecorder or Canvas stream not supported on this browser.',
        messageAr: 'المتصفح لا يدعم تسجيل الكانفاس مباشرة.',
      });
    }
  } catch (err: any) {
    results.push({
      id: 'test_canvas',
      name: 'Video Compositor & MediaRecorder Engine',
      nameAr: 'محرك دمج الفيديو وMediaRecorder',
      category: 'canvas',
      status: 'failed',
      durationMs: Math.round(performance.now() - t2Start),
      message: err.message,
      messageAr: err.message,
    });
  }

  // Test 3: Web Audio API & Speech Synthesis
  const t3Start = performance.now();
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    const hasSpeech = 'speechSynthesis' in window;
    if (AudioCtx) {
      results.push({
        id: 'test_audio',
        name: 'Web Audio Synthesizer & Speech Engine',
        nameAr: 'محرك معالجة الصوت والمؤثرات ونطق الحوارات',
        category: 'audio',
        status: 'passed',
        durationMs: Math.round(performance.now() - t3Start),
        message: `AudioContext online. Web Speech TTS supported: ${hasSpeech ? 'YES' : 'NO'}.`,
        messageAr: `محرك الصوتيات قيد التشغيل. دعم نطق الحوارات التفاعلي: ${hasSpeech ? 'مدعوم' : 'غير مدعوم'}.`,
      });
    } else {
      throw new Error('AudioContext unavailable');
    }
  } catch (err: any) {
    results.push({
      id: 'test_audio',
      name: 'Web Audio Synthesizer & Speech Engine',
      nameAr: 'محرك معالجة الصوت والمؤثرات ونطق الحوارات',
      category: 'audio',
      status: 'failed',
      durationMs: Math.round(performance.now() - t3Start),
      message: err.message,
      messageAr: err.message,
    });
  }

  // Test 4: Character Consistency Token Generator
  const t4Start = performance.now();
  try {
    const testChar = {
      name: 'Tester',
      role: 'Hero',
      facialFeatures: 'Blue eyes, high cheekbones',
      wardrobe: 'Black cloak',
    };
    const res = await fetch('/api/character/enhance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testChar),
    });
    const data = await res.json();
    if (res.ok && data.consistencyToken) {
      results.push({
        id: 'test_consistency',
        name: 'Character Consistency Token Engine',
        nameAr: 'محرك توليد توكن ثبات ملامح الشخصيات',
        category: 'consistency',
        status: 'passed',
        durationMs: Math.round(performance.now() - t4Start),
        message: `Generated consistency anchor token (${data.consistencyToken.length} chars).`,
        messageAr: `تم توليد توكن الثبات البصري بنجاح (${data.consistencyToken.length} حرف).`,
        details: data.consistencyToken,
      });
    } else {
      throw new Error(data.error || 'Failed to enhance token');
    }
  } catch (err: any) {
    results.push({
      id: 'test_consistency',
      name: 'Character Consistency Token Engine',
      nameAr: 'محرك توليد توكن ثبات ملامح الشخصيات',
      category: 'consistency',
      status: 'failed',
      durationMs: Math.round(performance.now() - t4Start),
      message: err.message,
      messageAr: err.message,
    });
  }

  // Test 5: Local Storage & Project Manifest Serialization
  const t5Start = performance.now();
  try {
    const testKey = 'am_cinema_test_manifest';
    const testData = { app: 'AM CINEMA AI', version: '2.0', ts: Date.now() };
    localStorage.setItem(testKey, JSON.stringify(testData));
    const loaded = JSON.parse(localStorage.getItem(testKey) || '{}');
    localStorage.removeItem(testKey);

    if (loaded.app === 'AM CINEMA AI') {
      results.push({
        id: 'test_storage',
        name: 'Project Manifest Storage & Auto-Save',
        nameAr: 'حفظ واسترجاع مشاريع الأفلام محلياً',
        category: 'storage',
        status: 'passed',
        durationMs: Math.round(performance.now() - t5Start),
        message: 'LocalStorage read/write verified. Auto-save operational.',
        messageAr: 'تم التحقق من القراءة والكتابة والحفظ التلقائي للمشاريع بنجاح.',
      });
    } else {
      throw new Error('Data mismatch');
    }
  } catch (err: any) {
    results.push({
      id: 'test_storage',
      name: 'Project Manifest Storage & Auto-Save',
      nameAr: 'حفظ واسترجاع مشاريع الأفلام محلياً',
      category: 'storage',
      status: 'failed',
      durationMs: Math.round(performance.now() - t5Start),
      message: err.message,
      messageAr: err.message,
    });
  }

  return results;
}
