/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Timeline, Editing Suite & Real Video Exporter
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Layers,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Film,
  Sparkles,
  Scissors,
  Check,
  AlertCircle,
  RefreshCw,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  Music,
  Trash2,
  Sliders,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CinemaProject, Shot, TransitionType } from '../types/cinema';
import { VideoCompositor, RenderProgressUpdate } from '../utils/videoExporter';
import { cinemaAudio } from '../utils/audioPlayer';

interface TimelineEditorViewProps {
  project: CinemaProject;
  onUpdateProject: (updated: CinemaProject) => void;
  lang: 'ar' | 'en';
}

export const TimelineEditorView: React.FC<TimelineEditorViewProps> = ({
  project,
  onUpdateProject,
  lang,
}) => {
  const isAr = lang === 'ar';

  // Flatten all shots
  const allShots: Shot[] = [];
  project.scenes.forEach((sc) => {
    sc.shots.forEach((sh) => allShots.push(sh));
  });

  const totalDuration = allShots.reduce((acc, s) => acc + (s.durationSeconds || 4), 0);

  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0); // in seconds
  const [activeShotIndex, setActiveShotIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Export state
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<RenderProgressUpdate | null>(null);
  const [exportedVideoUrl, setExportedVideoUrl] = useState<string | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);

  const playerContainerRef = useRef<HTMLDivElement>(null);
  const compositorRef = useRef<VideoCompositor | null>(null);

  // Master playback timer
  useEffect(() => {
    if (!isPlaying) return;

    const interval = 50; // ms
    const timer = setInterval(() => {
      setCurrentTime((prev) => {
        const next = prev + interval / 1000;
        if (next >= totalDuration) {
          setIsPlaying(false);
          return 0;
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [isPlaying, totalDuration]);

  // Determine which shot is currently playing based on currentTime
  useEffect(() => {
    let accumulated = 0;
    for (let i = 0; i < allShots.length; i++) {
      const shotDur = allShots[i].durationSeconds || 4;
      if (currentTime >= accumulated && currentTime < accumulated + shotDur) {
        if (activeShotIndex !== i) {
          setActiveShotIndex(i);
          // Play transition sound or dialogue
          if (!isMuted) {
            cinemaAudio.playCinematicSound('whoosh');
            const d = allShots[i].dialogue;
            if (d && (d.textAr || d.text)) {
              cinemaAudio.speakDialogue(isAr ? d.textAr : d.text, isAr ? 'ar' : 'en', d.emotion);
            }
          }
        }
        break;
      }
      accumulated += shotDur;
    }
  }, [currentTime, allShots, activeShotIndex, isMuted, isAr]);

  const currentShot = allShots[activeShotIndex] || allShots[0];

  // Calculate progress within current shot for camera simulation
  const getProgressInCurrentShot = () => {
    if (!currentShot) return 0;
    let accumulatedBefore = 0;
    for (let i = 0; i < activeShotIndex; i++) {
      accumulatedBefore += allShots[i].durationSeconds || 4;
    }
    const shotDur = currentShot.durationSeconds || 4;
    const elapsedInShot = Math.max(0, currentTime - accumulatedBefore);
    return Math.min(1.0, elapsedInShot / shotDur);
  };

  const getActiveShotCameraTransform = () => {
    if (!currentShot) return {};
    const progress = getProgressInCurrentShot();
    const strength = (currentShot.motionStrength || 5) / 10;

    switch (currentShot.cameraMovement) {
      case 'zoom_in':
        return { transform: `scale(${1.0 + progress * 0.25 * strength})` };
      case 'zoom_out':
        return { transform: `scale(${1.25 - progress * 0.25 * strength})` };
      case 'pan_left':
        return { transform: `scale(1.15) translateX(${-progress * 60 * strength}px)` };
      case 'pan_right':
        return { transform: `scale(1.15) translateX(${progress * 60 * strength}px)` };
      case 'tilt_up':
        return { transform: `scale(1.15) translateY(${-progress * 45 * strength}px)` };
      case 'tilt_down':
        return { transform: `scale(1.15) translateY(${progress * 45 * strength}px)` };
      case 'camera_tracking':
      case 'orbit_360':
      case 'crane_shot':
        return {
          transform: `scale(${1.08 + Math.sin(progress * Math.PI) * 0.15 * strength}) translateX(${Math.cos(progress * Math.PI) * 30 * strength}px)`,
        };
      default:
        return { transform: 'scale(1.03)' };
    }
  };

  // Reorder shots in sequence
  const handleMoveShot = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= allShots.length) return;

    // We can swap inside scenes
    const reordered = [...allShots];
    const temp = reordered[index];
    reordered[index] = reordered[targetIndex];
    reordered[targetIndex] = temp;

    // Reconstruct scene shots
    let shotPointer = 0;
    const updatedScenes = project.scenes.map((sc) => {
      const sceneShotsCount = sc.shots.length;
      const slice = reordered.slice(shotPointer, shotPointer + sceneShotsCount);
      shotPointer += sceneShotsCount;
      return { ...sc, shots: slice };
    });

    onUpdateProject({ ...project, scenes: updatedScenes, updatedAt: Date.now() });
    cinemaAudio.playCinematicSound('click');
  };

  // Change transition
  const handleChangeTransition = (shotId: string, newTrans: TransitionType) => {
    const updatedScenes = project.scenes.map((sc) => ({
      ...sc,
      shots: sc.shots.map((sh) => (sh.id === shotId ? { ...sh, transitionToNext: newTrans } : sh)),
    }));
    onUpdateProject({ ...project, scenes: updatedScenes, updatedAt: Date.now() });
    cinemaAudio.playCinematicSound('click');
  };

  // Render & Export Video
  const handleStartExport = async () => {
    if (allShots.length === 0) return;
    setIsPlaying(false);
    setShowExportModal(true);
    setIsExporting(true);
    setExportProgress({ percent: 1, currentShot: 1, totalShots: allShots.length, statusText: 'Initializing...' });
    setExportedVideoUrl(null);

    cinemaAudio.playCinematicSound('drone');

    try {
      const compositor = new VideoCompositor(1280, 720);
      compositorRef.current = compositor;

      const videoUrl = await compositor.renderProjectToVideo(project, (update) => {
        setExportProgress(update);
      });

      setExportedVideoUrl(videoUrl);
      setIsExporting(false);
      cinemaAudio.playCinematicSound('bell');

      // Trigger celebration confetti
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#fbbf24', '#ffffff', '#b45309'],
      });
    } catch (err: any) {
      console.error('Export error:', err);
      setIsExporting(false);
      alert(err.message || 'Export failed');
    }
  };

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Top Controls Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'غرفة المونتاج ودمج المشاهد والتصدير' : 'Editing Suite & Master Video Timeline'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Film className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'معاينة الفيلم كاملاً وتصدير الفيديو الفعلي' : 'Full Movie Preview & Video Export'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1">
            {isAr
              ? `إجمالي المشاهد: ${project.scenes.length} • إجمالي اللقطات: ${allShots.length} • مدة العرض الإجمالية: ${formatTime(totalDuration)}`
              : `Scenes: ${project.scenes.length} • Shots: ${allShots.length} • Total Runtime: ${formatTime(totalDuration)}`}
          </p>
        </div>

        {/* Master Export Video Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleStartExport}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-stone-950 shadow-xl shadow-amber-500/25 transition-all transform hover:scale-[1.02]"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>{isAr ? 'تصدير الفيلم (فيديو حقيقي .webm)' : 'Export Full Movie (Real .webm)'}</span>
          </button>
        </div>
      </div>

      {/* Master Cinema Screen Player */}
      <div
        ref={playerContainerRef}
        className={`relative rounded-2xl overflow-hidden bg-black border border-stone-800 shadow-2xl flex flex-col items-center justify-center ${
          isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'w-full max-w-4xl mx-auto aspect-video'
        }`}
      >
        {/* Active Frame with live camera motion */}
        {currentShot?.imageUrl ? (
          <div
            className="w-full h-full transition-transform duration-75 ease-out origin-center"
            style={getActiveShotCameraTransform()}
          >
            <img
              src={currentShot.imageUrl}
              alt={currentShot.title}
              className="w-full h-full object-cover pointer-events-none"
            />
          </div>
        ) : (
          <div className="text-center p-6 space-y-2 text-stone-500">
            <Film className="w-12 h-12 mx-auto text-amber-500/40 animate-pulse" />
            <p className="text-sm font-semibold">{isAr ? 'في انتظار توليد لقطات الفيلم' : 'No shots ready yet'}</p>
          </div>
        )}

        {/* Cinemascope 2.39:1 Letterbox Bars */}
        {project.settings.aspectRatio === '2.39:1' && (
          <>
            <div className="absolute top-0 left-0 right-0 h-[12%] bg-[#060608] border-b border-amber-500/20 pointer-events-none" />
            <div className="absolute bottom-0 left-0 right-0 h-[12%] bg-[#060608] border-t border-amber-500/20 pointer-events-none" />
          </>
        )}

        {/* Live Subtitles Overlay */}
        {currentShot?.dialogue && currentShot.dialogue.textAr && (
          <div className="absolute bottom-14 left-6 right-6 flex justify-center pointer-events-none">
            <div className="px-4 py-1.5 rounded-lg bg-black/75 backdrop-blur-sm border border-stone-800 text-amber-200 text-sm sm:text-base font-semibold text-center drop-shadow-md">
              <span className="text-amber-400 font-bold">{currentShot.dialogue.speakerName}: </span>
              <span>{isAr ? currentShot.dialogue.textAr : currentShot.dialogue.text}</span>
            </div>
          </div>
        )}

        {/* Top HUD Branding */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs pointer-events-none">
          <div className="flex items-center gap-2">
            <span className="font-cinematic font-bold text-amber-400 text-sm drop-shadow">
              AM CINEMA AI
            </span>
            <span className="text-[10px] text-stone-400 px-2 py-0.5 rounded bg-black/60 border border-stone-800">
              SHOT {activeShotIndex + 1}/{allShots.length} [{currentShot?.cameraMovement}]
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs text-amber-300 px-2 py-0.5 rounded bg-black/60 border border-stone-800">
            <span>{formatTime(currentTime)}</span>
            <span className="text-stone-500">/</span>
            <span>{formatTime(totalDuration)}</span>
          </div>
        </div>

        {/* Bottom Cinema Controls Bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (isPlaying) {
                  setIsPlaying(false);
                } else {
                  setIsPlaying(true);
                  cinemaAudio.playCinematicSound('whoosh');
                }
              }}
              className="p-2.5 rounded-full bg-amber-500 hover:bg-amber-600 text-stone-950 transition shadow-lg shadow-amber-500/20"
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
            </button>

            <button
              onClick={() => {
                setCurrentTime(0);
                setActiveShotIndex(0);
                setIsPlaying(false);
              }}
              className="p-2 rounded-lg bg-stone-900/80 hover:bg-stone-800 text-stone-300 border border-stone-700 transition"
              title={isAr ? 'إعادة من البداية' : 'Restart'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-lg bg-stone-900/80 hover:bg-stone-800 text-stone-300 border border-stone-700 transition"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
            </button>
          </div>

          {/* Scrubber Bar */}
          <div className="flex-1 max-w-xl mx-4">
            <input
              type="range"
              min={0}
              max={totalDuration || 1}
              step={0.1}
              value={currentTime}
              onChange={(e) => {
                setCurrentTime(parseFloat(e.target.value));
              }}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-stone-800 rounded-lg"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-lg bg-stone-900/80 hover:bg-stone-800 text-stone-300 border border-stone-700 transition"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Multi-Track Visual Timeline */}
      <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-stone-200">
              {isAr ? 'شريط تتابع اللقطات والانتقالات والموسيقى' : 'Interactive Multi-Track Sequencer'}
            </h3>
          </div>
          <span className="text-xs text-stone-400 font-mono">
            {allShots.length} {isAr ? 'لقطات مدمجة' : 'shots sequenced'}
          </span>
        </div>

        {/* Track 1: Shots Cards Track */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-stone-400 flex items-center gap-1.5">
            <Film className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'مسار الفيديو واللقطات (Video Track):' : 'Track 1: Video Shots'}</span>
          </span>

          <div className="flex items-center gap-2 overflow-x-auto pb-3 pt-1 scrollbar-thin">
            {allShots.map((shot, idx) => {
              const isActive = idx === activeShotIndex;
              return (
                <div key={shot.id} className="flex items-center shrink-0">
                  {/* Shot Card */}
                  <div
                    onClick={() => {
                      // Seek to shot start time
                      let acc = 0;
                      for (let i = 0; i < idx; i++) {
                        acc += allShots[i].durationSeconds || 4;
                      }
                      setCurrentTime(acc);
                      setActiveShotIndex(idx);
                    }}
                    className={`relative w-44 rounded-xl overflow-hidden border cursor-pointer transition-all ${
                      isActive
                        ? 'border-amber-500 ring-2 ring-amber-500/40 shadow-lg shadow-amber-500/10'
                        : 'border-stone-800 hover:border-stone-700 bg-stone-950'
                    }`}
                  >
                    <div className="h-24 w-full bg-stone-900 relative">
                      {shot.imageUrl ? (
                        <img src={shot.imageUrl} alt={shot.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[10px] text-stone-600">
                          No Keyframe
                        </div>
                      )}

                      <div className="absolute top-1.5 left-1.5 px-1.5 py-0.2 rounded bg-black/80 text-[10px] font-mono text-amber-300 font-bold">
                        #{idx + 1}
                      </div>

                      <div className="absolute top-1.5 right-1.5 px-1.5 py-0.2 rounded bg-black/80 text-[10px] text-stone-300">
                        {shot.durationSeconds}s
                      </div>

                      <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-[9px] text-stone-300">
                        <span className="px-1 py-0.2 rounded bg-black/80">{shot.cameraMovement}</span>
                        <span className="px-1 py-0.2 rounded bg-black/80">{shot.framing}</span>
                      </div>
                    </div>

                    <div className="p-2 space-y-1 bg-[#0e0e14]">
                      <p className="text-[11px] font-bold text-stone-200 line-clamp-1">
                        {isAr ? shot.titleAr || shot.title : shot.title}
                      </p>

                      {/* Reorder Buttons */}
                      <div className="flex items-center justify-between pt-1 border-t border-stone-800">
                        <div className="flex items-center gap-1">
                          {idx > 0 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveShot(idx, 'left');
                              }}
                              className="p-1 rounded hover:bg-stone-800 text-stone-400 hover:text-white"
                              title={isAr ? 'تقديم لليمين' : 'Move Left'}
                            >
                              <ChevronLeft className="w-3 h-3" />
                            </button>
                          )}
                          {idx < allShots.length - 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveShot(idx, 'right');
                              }}
                              className="p-1 rounded hover:bg-stone-800 text-stone-400 hover:text-white"
                              title={isAr ? 'تأخير لليسار' : 'Move Right'}
                            >
                              <ChevronRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                        <span className="text-[10px] font-mono text-stone-500">{shot.resolution}</span>
                      </div>
                    </div>
                  </div>

                  {/* Transition connector node between shots */}
                  {idx < allShots.length - 1 && (
                    <div className="px-2 flex flex-col items-center">
                      <select
                        value={shot.transitionToNext}
                        onChange={(e) => handleChangeTransition(shot.id, e.target.value as TransitionType)}
                        className="px-1.5 py-1 rounded bg-stone-900 border border-stone-800 text-[10px] text-amber-400 font-mono outline-none hover:border-amber-500/40"
                        title={isAr ? 'تغيير نوع الانتقال' : 'Transition Type'}
                      >
                        <option value="crossfade">Crossfade (تلاشي متقاطع)</option>
                        <option value="cut">Hard Cut (قطع مباشر)</option>
                        <option value="fade_black">Fade Black (تلاشي للأسود)</option>
                        <option value="dissolve">Dissolve (انحلال ناعم)</option>
                        <option value="whip_pan">Whip Pan (تحريك سريع)</option>
                      </select>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Track 2: Dialogue & Voices Track */}
        <div className="space-y-1.5 border-t border-stone-800 pt-3">
          <span className="text-[11px] font-bold text-stone-400 flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'مسار الحوارات والأصوات (Dialogue & Lip Sync Track):' : 'Track 2: Character Dialogues'}</span>
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {allShots.map((sh, idx) => {
              if (!sh.dialogue) return null;
              return (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-stone-950 border border-stone-800 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5 max-w-[80%]">
                    <span className="text-[10px] font-bold text-amber-400">
                      SH #{idx + 1} • {sh.dialogue.speakerName} ({sh.dialogue.emotion})
                    </span>
                    <p className="text-[11px] text-stone-300 line-clamp-1">
                      {isAr ? sh.dialogue.textAr : sh.dialogue.text}
                    </p>
                  </div>
                  <button
                    onClick={() => cinemaAudio.speakDialogue(isAr ? sh.dialogue!.textAr : sh.dialogue!.text, isAr ? 'ar' : 'en', sh.dialogue!.emotion)}
                    className="p-1.5 rounded bg-stone-900 hover:bg-stone-800 text-stone-300 hover:text-amber-300"
                    title={isAr ? 'اختبار النطق' : 'Test Speech'}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Track 3: Cinematic Score & SFX */}
        <div className="border-t border-stone-800 pt-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Music className="w-4 h-4 text-amber-400" />
            <div>
              <span className="text-xs font-bold text-stone-200">
                {isAr ? 'الموسيقى التصويرية والمؤثرات:' : 'Master Soundtrack & Atmospheric Foley:'}
              </span>
              <p className="text-[11px] text-stone-400">
                {project.audioTrack?.musicStyle || 'Epic Middle-Eastern Orchestral & Duduk Strings'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-stone-400">
            <span>{isAr ? 'مستوى الصوت:' : 'Volume:'}</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              defaultValue={project.audioTrack?.volume || 0.75}
              className="accent-amber-500 cursor-pointer w-24"
            />
          </div>
        </div>
      </div>

      {/* Export & Render Progress Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0e0e13] border border-amber-500/40 rounded-2xl w-full max-w-lg p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <Film className="w-5 h-5 text-amber-400" />
                <span>{isAr ? 'تصدير الفيلم السينمائي النهائي' : 'Master Film Rendering'}</span>
              </h3>
              {!isExporting && (
                <button
                  onClick={() => setShowExportModal(false)}
                  className="text-stone-400 hover:text-white p-1"
                >
                  ✕
                </button>
              )}
            </div>

            {isExporting ? (
              <div className="py-8 space-y-4 text-center">
                <RefreshCw className="w-10 h-10 animate-spin text-amber-400 mx-auto" />
                <div className="space-y-1">
                  <p className="text-sm font-bold text-white">
                    {exportProgress?.statusText || (isAr ? 'جاري دمج اللقطات وتطبيق حركات الكاميرا...' : 'Rendering cinema master...')}
                  </p>
                  <p className="text-xs text-amber-400 font-mono">
                    {exportProgress?.percent || 0}% — {isAr ? `اللقطة ${exportProgress?.currentShot} من ${exportProgress?.totalShots}` : `Shot ${exportProgress?.currentShot} of ${exportProgress?.totalShots}`}
                  </p>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-stone-800 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-400 to-amber-600 h-2.5 transition-all duration-150"
                    style={{ width: `${exportProgress?.percent || 5}%` }}
                  />
                </div>
              </div>
            ) : exportedVideoUrl ? (
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>
                    {isAr
                      ? 'تم تصدير الفيلم السينمائي بنجاح! يمكنك الآن مشاهدته وتنزيل ملف الفيديو المكتمل.'
                      : 'Cinema master exported successfully! Ready for playback and download.'}
                  </span>
                </div>

                {/* Live Downloaded Video Player */}
                <div className="rounded-xl overflow-hidden bg-black border border-stone-800 aspect-video">
                  <video
                    src={exportedVideoUrl}
                    controls
                    autoPlay
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <a
                    href={exportedVideoUrl}
                    download={`${project.title.replace(/\s+/g, '_')}_AM_CINEMA.webm`}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-lg shadow-amber-500/20 transition"
                  >
                    <Download className="w-4 h-4 stroke-[3]" />
                    <span>{isAr ? 'تنزيل ملف الفيديو (.webm)' : 'Download Movie (.webm)'}</span>
                  </a>
                  <button
                    onClick={() => setShowExportModal(false)}
                    className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stone-400 hover:text-white bg-stone-900 border border-stone-800"
                  >
                    {isAr ? 'إغلاق' : 'Close'}
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};
