/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Diagnostics & Test Suite
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState, useEffect } from 'react';
import {
  Activity,
  CheckCircle,
  XCircle,
  RefreshCw,
  Cpu,
  Layers,
  Volume2,
  Database,
  ShieldCheck,
  Smartphone,
  Play,
} from 'lucide-react';
import { runCinemaDiagnostics, DiagnosticResult } from '../utils/directorDiagnostics';
import { cinemaAudio } from '../utils/audioPlayer';

interface DiagnosticsViewProps {
  lang: 'ar' | 'en';
}

export const DiagnosticsView: React.FC<DiagnosticsViewProps> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [results, setResults] = useState<DiagnosticResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const executeTests = async () => {
    setIsRunning(true);
    cinemaAudio.playCinematicSound('drone');
    try {
      const tests = await runCinemaDiagnostics();
      setResults(tests);
      cinemaAudio.playCinematicSound('bell');
    } catch (e) {
      console.error(e);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    executeTests();
  }, []);

  const passedCount = results.filter((r) => r.status === 'passed').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'فحص جاهزية النظام والبيئة التشغيلية' : 'System Diagnostic & Unit Test Suite'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'الفحص الآلي للوظائف الأساسية وتجهيز نسخة Android' : 'Core Diagnostics & Android Readiness'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1 max-w-2xl">
            {isAr
              ? 'اختبارات برمجية حقيقية للتحقق من: اتصال بوابة الذكاء الاصطناعي، محرك دمج الفيديو في الكانفاس، معالجة الصوت، توليد توكن الشخصيات، والحفظ التلقائي.'
              : 'Verifies backend gateway, MediaRecorder canvas stream, Web Audio synthesis, consistency token engine, and project persistence.'}
          </p>
        </div>

        <button
          disabled={isRunning}
          onClick={executeTests}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-xs bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-lg shadow-amber-500/20 transition"
        >
          <RefreshCw className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? (isAr ? 'جاري الفحص...' : 'Running...') : (isAr ? 'إعادة تشغيل الاختبارات' : 'Rerun Test Suite')}</span>
        </button>
      </div>

      {/* Summary Score */}
      <div className="p-6 rounded-2xl bg-[#0c0c10] border border-amber-500/30 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
            <span className="text-xl font-black text-amber-400 font-mono">
              {passedCount}/{results.length}
            </span>
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {passedCount === results.length && results.length > 0
                ? isAr ? 'جميع الاختبارات نجحت بنسبة 100%' : 'All Diagnostics Passed (100%)'
                : isAr ? 'نتائج الفحص والتحقق' : 'Diagnostics Status'}
            </h3>
            <p className="text-xs text-stone-400">
              {isAr ? 'التطبيق مهيأ للعمل المكتبي والهواتف الذكية (Android Responsive).' : 'Engine primed for web and mobile Android environments.'}
            </p>
          </div>
        </div>

        {/* Android PWA Readiness Badge */}
        <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-stone-900 border border-stone-800 text-xs text-stone-300">
          <Smartphone className="w-4 h-4 text-amber-400" />
          <span>{isAr ? 'جاهز للتثبيت على Android (PWA Web App)' : 'Android PWA Compliant'}</span>
        </div>
      </div>

      {/* Tests Results List */}
      <div className="space-y-3">
        {results.map((test) => {
          const isPassed = test.status === 'passed';
          return (
            <div
              key={test.id}
              className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition ${
                isPassed
                  ? 'bg-[#0a0a0e] border-stone-800/90 hover:border-emerald-500/30'
                  : 'bg-rose-950/20 border-rose-900/60'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {isPassed ? (
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-stone-100">
                      {isAr ? test.nameAr : test.name}
                    </h4>
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-stone-900 text-stone-400 border border-stone-800">
                      {test.category}
                    </span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {isAr ? test.messageAr : test.message}
                  </p>
                  {test.details && (
                    <p className="text-[10px] font-mono text-amber-300/80 mt-1 select-all bg-black/50 p-1.5 rounded border border-stone-800">
                      {test.details}
                    </p>
                  )}
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[11px] font-mono text-stone-500">{test.durationMs}ms</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
