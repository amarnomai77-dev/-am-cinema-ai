/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Auto Director Mode (الوضع التلقائي)
 * Inspired by Google Flow Cinema Experience
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Clapperboard,
  Camera,
  Play,
  Volume2,
  Clock,
  Layers,
  Check,
  AlertCircle,
  RefreshCw,
  Film,
  Zap,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { CinemaProject, Scene, Shot, TransitionType } from '../types/cinema';
import { cinemaAudio } from '../utils/audioPlayer';

interface AutoDirectorViewProps {
  project: CinemaProject;
  onUpdateProject: (updated: CinemaProject) => void;
  onNavigateTab: (tab: any) => void;
  lang: 'ar' | 'en';
}

export const AutoDirectorView: React.FC<AutoDirectorViewProps> = ({
  project,
  onUpdateProject,
  onNavigateTab,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [synopsis, setSynopsis] = useState(project.synopsis || '');
  const [targetDuration, setTargetDuration] = useState(project.settings.targetDurationSeconds || 120);
  const [genre, setGenre] = useState(project.settings.genre || 'Cinematic Sci-Fi');
  const [visualStyle, setVisualStyle] = useState(project.settings.visualStyle || '35mm Film Panavision Gold & Shadow');
  const [selectedCharIds, setSelectedCharIds] = useState<string[]>(
    project.characters.map((c) => c.id)
  );

  const [isDecomposing, setIsDecomposing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const toggleCharSelection = (id: string) => {
    if (selectedCharIds.includes(id)) {
      setSelectedCharIds(selectedCharIds.filter((cid) => cid !== id));
    } else {
      setSelectedCharIds([...selectedCharIds, id]);
    }
  };

  const handleDecompose = async () => {
    if (!synopsis.trim()) {
      setErrorMessage(isAr ? 'يرجى كتابة ملخص أو قصة الفيلم أولاً' : 'Please provide a story synopsis first');
      return;
    }

    setIsDecomposing(true);
    setErrorMessage(null);
    setSuccessNotice(null);
    cinemaAudio.playCinematicSound('drone');

    try {
      const activeChars = project.characters.filter((c) => selectedCharIds.includes(c.id));

      const response = await fetch('/api/director/decompose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: project.title,
          synopsis,
          targetDuration,
          genre,
          visualStyle,
          characters: activeChars,
          aspectRatio: project.settings.aspectRatio,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to decompose story');
      }

      // Convert returned scenes to internal model with IDs
      const newScenes: Scene[] = (data.scenes || []).map((sc: any, scIdx: number) => {
        const sceneId = `sc_${Date.now()}_${scIdx}`;
        return {
          id: sceneId,
          sceneNumber: sc.sceneNumber || scIdx + 1,
          title: sc.title || `Scene ${scIdx + 1}`,
          titleAr: sc.titleAr || `المشهد ${scIdx + 1}`,
          location: sc.location || 'Cinematic Set',
          locationAr: sc.locationAr || 'موقع سينمائي',
          timeOfDay: sc.timeOfDay || 'golden_hour',
          weatherOrAtmosphere: sc.weatherOrAtmosphere || 'Atmospheric cinematic dust',
          dramaticBeat: sc.dramaticBeat || 'Key dramatic turning point',
          shots: (sc.shots || []).map((sh: any, shIdx: number) => {
            const shotId = `sh_${Date.now()}_${scIdx}_${shIdx}`;
            return {
              id: shotId,
              sceneId,
              shotNumber: sh.shotNumber || shIdx + 1,
              title: sh.title || `Shot ${shIdx + 1}`,
              titleAr: sh.titleAr || `لقطة ${shIdx + 1}`,
              framing: sh.framing || 'medium_shot',
              cameraMovement: sh.cameraMovement || 'zoom_in',
              focalLength: sh.focalLength || '35mm',
              motionStrength: sh.motionStrength || 5,
              durationSeconds: sh.durationSeconds || 4,
              resolution: project.settings.defaultResolution,
              visualPrompt: sh.visualPrompt || '',
              visualPromptAr: sh.visualPromptAr || '',
              negativePrompt: sh.negativePrompt || 'blurry, distorted face, low quality, oversaturated',
              characterIds: activeChars.map((c) => c.id),
              lightingStyle: sh.lightingStyle || 'Dramatic cinematic lighting with amber glow',
              dialogue: sh.dialogueSpeaker && sh.dialogueText
                ? {
                    id: `dia_${Date.now()}_${shIdx}`,
                    speakerName: sh.dialogueSpeaker,
                    text: sh.dialogueText,
                    textAr: sh.dialogueTextAr || sh.dialogueText,
                    emotion: sh.dialogueEmotion || 'dramatic',
                    durationSeconds: sh.durationSeconds || 4,
                  }
                : undefined,
              ambientSound: sh.ambientSound || 'Cinematic room tone',
              musicIntensity: sh.musicIntensity || 'building',
              transitionToNext: (sh.transitionToNext as TransitionType) || 'crossfade',
              // Pre-assign instant cinematic placeholder keyframe
              imageUrl: `https://image.pollinations.ai/prompt/${encodeURIComponent(sh.visualPrompt || 'cinematic film still 35mm')}&width=1280&height=720&seed=${Math.floor(Math.random() * 99999)}&nologo=true`,
            };
          }),
        };
      });

      const totalSecs = newScenes.reduce(
        (acc, sc) => acc + sc.shots.reduce((shAcc, sh) => shAcc + (sh.durationSeconds || 4), 0),
        0
      );

      const updatedProject: CinemaProject = {
        ...project,
        title: data.title || project.title,
        titleAr: data.titleAr || project.titleAr,
        logline: data.logline || project.logline,
        loglineAr: data.loglineAr || project.loglineAr,
        synopsis,
        settings: {
          ...project.settings,
          targetDurationSeconds: targetDuration,
          genre,
          visualStyle,
          filmColorPalette: data.colorPalette || project.settings.filmColorPalette,
        },
        scenes: newScenes,
        totalDurationSeconds: totalSecs,
        updatedAt: Date.now(),
      };

      onUpdateProject(updatedProject);
      cinemaAudio.playCinematicSound('bell');
      setSuccessNotice(
        isAr
          ? `تم إنجاز التوزيع الإخراجي بنجاح! تم إنشاء ${newScenes.length} مشاهد و${newScenes.reduce((a, s) => a + s.shots.length, 0)} لقطة متسلسلة.`
          : `Master breakdown complete! Generated ${newScenes.length} scenes and ${newScenes.reduce((a, s) => a + s.shots.length, 0)} sequential shots.`
      );
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to decompose story');
    } finally {
      setIsDecomposing(false);
    }
  };

  const handleTestDialogueSpeech = (text: string, langCode: 'ar' | 'en') => {
    cinemaAudio.speakDialogue(text, langCode, 'dramatic');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Title & Philosophy Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'الوضع التلقائي — المخرج الذكي' : 'Auto Director Mode — Google Flow Inspired'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Clapperboard className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'تفكيك السيناريو وتوزيع المشاهد واللقطات' : 'Script Breakdown & Cinematic Orchestration'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1 max-w-3xl">
            {isAr
              ? 'يقوم المخرج الآلي بتحليل قصة الفيلم، وتقسيمها إلى مشاهد ولقطات قصيرة (من 2 إلى 3 دقائق إجمالاً)، وتحديد حركات الكاميرا المناسبة، وتثبيت هوية وملامح الشخصيات عبر المشاهد.'
              : 'Auto Director deconstructs your premise into shot-by-shot scenes (targeting 2-3 mins total), calculating camera choreographies, dialogue timing, and character consistency.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateTab('timeline')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 transition"
          >
            <Film className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'معاينة في المونتاج' : 'View in Timeline'}</span>
          </button>
        </div>
      </div>

      {/* Script & Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Story Premise Input */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-stone-200 flex items-center gap-2">
                <Film className="w-4 h-4 text-amber-400" />
                <span>{isAr ? 'قصة أو سيناريو الفيلم:' : 'Story Premise / Full Screenplay Synopsis:'}</span>
              </label>
              <span className="text-xs text-stone-500 font-mono">
                {synopsis.length} {isAr ? 'حرف' : 'chars'}
              </span>
            </div>

            <textarea
              rows={6}
              value={synopsis}
              onChange={(e) => setSynopsis(e.target.value)}
              placeholder={
                isAr
                  ? 'اكتب قصة فيلمك هنا بالتفصيل: ما هو الصراع الرئيسي؟ من هم الأبطال؟ وما هو المشهد الحاسم؟ على سبيل المثال: في مدينة بابل المعلقة، يسابق الخيميائي طارق والملاحة ليلى عقارب الكسوف الشمسي لتشغيل الإسطرلاب الذهبي الأسطوري...'
                  : 'Enter your cinematic story synopsis or screenplay draft here...'
              }
              className="w-full px-4 py-3 rounded-lg bg-stone-950 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm leading-relaxed outline-none"
            />

            {/* Target Duration Selector (Short Film 60s, 120s, 180s) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-xs text-stone-400 font-medium flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isAr ? 'مدة الفيلم المستهدفة:' : 'Target Runtime:'}</span>
                </label>
                <select
                  value={targetDuration}
                  onChange={(e) => setTargetDuration(parseInt(e.target.value, 10))}
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                >
                  <option value={60}>1 {isAr ? 'دقيقة (60 ثانية — فيلم سريع)' : 'Minute (60s Short)'}</option>
                  <option value={120}>2 {isAr ? 'دقيقتان (120 ثانية — إنتاج قياسي)' : 'Minutes (120s Standard)'}</option>
                  <option value={180}>3 {isAr ? 'دقائق (180 ثانية — فيلم سينمائي كامل)' : 'Minutes (180s Full Cinema)'}</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-stone-400 font-medium">
                  {isAr ? 'التصنيف الدرامي:' : 'Genre:'}
                </label>
                <input
                  type="text"
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-stone-400 font-medium">
                  {isAr ? 'الأسلوب البصري وحبيبات الفيلم:' : 'Visual Style & Grain:'}
                </label>
                <select
                  value={visualStyle}
                  onChange={(e) => setVisualStyle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                >
                  <option value="35mm Film Panavision Gold & Shadow">35mm Panavision Gold & Shadow</option>
                  <option value="Cyberpunk Neon Noir Chiaroscuro">Cyberpunk Neon Noir</option>
                  <option value="Epic IMAX 70mm Historical Naturalism">IMAX 70mm Historical Epic</option>
                  <option value="Vintage Technicolor 1960s Cinema">Vintage 1960s Technicolor</option>
                  <option value="Gritty Neo-Realistic Handheld Drama">Neo-Realistic Drama</option>
                </select>
              </div>
            </div>

            {/* Error or Success notification */}
            {errorMessage && (
              <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {successNotice && (
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{successNotice}</span>
              </div>
            )}

            {/* Execute Decompose Action */}
            <div className="pt-2">
              <button
                type="button"
                disabled={isDecomposing}
                onClick={handleDecompose}
                className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-xl transition-all ${
                  isDecomposing
                    ? 'bg-stone-800 text-stone-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-stone-950 shadow-amber-500/20 transform hover:scale-[1.01]'
                }`}
              >
                {isDecomposing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                    <span>{isAr ? 'المخرج الآلي يقوم بتحليل القصة وتوزيع المشاهد...' : 'Auto Director Deconstructing Story...'}</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-current" />
                    <span>{isAr ? 'توليد التقسيم السينمائي الكامل (مشهد بمشهد)' : 'Generate Master Shot Breakdown'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Character Cast Consistency Checklist */}
        <div className="space-y-4">
          <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-5 space-y-3 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="text-sm font-bold text-stone-200 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-amber-400" />
                <span>{isAr ? 'طاقم الشخصيات المعتمد:' : 'Cast for Continuity:'}</span>
              </h3>
              <button
                onClick={() => onNavigateTab('characters')}
                className="text-[11px] text-amber-400 hover:underline"
              >
                {isAr ? '+ إضافة شخصية' : '+ Add Character'}
              </button>
            </div>

            <p className="text-[11px] text-stone-400 leading-relaxed">
              {isAr
                ? 'الشخصيات المحددة هنا سيتم تثبيت ملامحها وملابسها ودمج توكن الثبات البصري تلقائياً في وصف لقطات الفيلم.'
                : 'Checked characters will have their facial traits and consistency anchors woven into every shot description.'}
            </p>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {project.characters.map((char) => {
                const isSelected = selectedCharIds.includes(char.id);
                return (
                  <div
                    key={char.id}
                    onClick={() => toggleCharSelection(char.id)}
                    className={`p-2.5 rounded-lg border cursor-pointer transition flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500/40 text-stone-100'
                        : 'bg-stone-900/60 border-stone-800/80 text-stone-400 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-md overflow-hidden bg-stone-800 shrink-0 border border-stone-700">
                        {char.referenceImageUrl ? (
                          <img src={char.referenceImageUrl} alt={char.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs font-bold text-amber-400">
                            {char.name[0]}
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-amber-200">{isAr ? char.nameAr || char.name : char.name}</p>
                        <p className="text-[10px] text-stone-400">{char.role} • {char.age}y</p>
                      </div>
                    </div>

                    <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-amber-500 border-amber-500 text-stone-950' : 'border-stone-700'}`}>
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Generated Scenes & Shots Breakdown Display */}
      {project.scenes && project.scenes.length > 0 && (
        <div className="space-y-6 pt-4">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
            <div>
              <h3 className="text-lg font-bold text-stone-100 flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-400" />
                <span>{isAr ? 'الخطة الإخراجية المعتمدة للفيلم' : 'Director Master Breakdown'}</span>
                <span className="text-xs font-normal text-amber-400/80">
                  ({project.scenes.length} {isAr ? 'مشاهد' : 'scenes'} • {project.scenes.reduce((a, s) => a + s.shots.length, 0)} {isAr ? 'لقطة' : 'shots'} • {project.totalDurationSeconds}s)
                </span>
              </h3>
            </div>

            <button
              onClick={() => onNavigateTab('manual_studio')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-stone-950 transition"
            >
              <span>{isAr ? 'تعديل في استوديو اللقطات' : 'Open in Shot Studio'}</span>
              {isAr ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="space-y-6">
            {project.scenes.map((scene) => (
              <div
                key={scene.id}
                className="rounded-xl bg-[#0b0b10] border border-stone-800/90 overflow-hidden shadow-xl"
              >
                {/* Scene Header */}
                <div className="p-4 bg-gradient-to-r from-stone-900 to-[#121218] border-b border-stone-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">
                      {isAr ? `مشهد ${scene.sceneNumber}` : `SCENE ${scene.sceneNumber}`}
                    </span>
                    <h4 className="text-sm font-bold text-white">
                      {isAr ? scene.titleAr || scene.title : scene.title}
                    </h4>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-stone-400">
                    <span className="px-2 py-0.5 rounded bg-black/60 border border-stone-800">
                      📍 {isAr ? scene.locationAr || scene.location : scene.location}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-black/60 border border-stone-800 text-amber-300">
                      ⏰ {scene.timeOfDay}
                    </span>
                  </div>
                </div>

                {/* Shots inside scene */}
                <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {scene.shots.map((shot) => (
                    <div
                      key={shot.id}
                      className="rounded-lg bg-stone-950/80 border border-stone-800/80 overflow-hidden flex flex-col justify-between hover:border-amber-500/40 transition group"
                    >
                      <div>
                        {/* Shot Thumbnail / Keyframe */}
                        <div className="relative h-32 w-full bg-stone-900 overflow-hidden">
                          {shot.imageUrl ? (
                            <img
                              src={shot.imageUrl}
                              alt={shot.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-stone-500">
                              {isAr ? 'في انتظار التوليد' : 'Pending Generation'}
                            </div>
                          )}

                          <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-sm border border-stone-700 text-[10px] font-mono font-bold text-amber-300">
                            SH {shot.shotNumber} • {shot.durationSeconds}s
                          </div>

                          <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-sm border border-stone-700 text-[10px] text-stone-300">
                            🎥 {shot.cameraMovement}
                          </div>

                          <div className="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-black/80 text-[10px] text-stone-300">
                            🔍 {shot.framing}
                          </div>
                        </div>

                        {/* Shot Details */}
                        <div className="p-3 space-y-2">
                          <h5 className="text-xs font-bold text-stone-100 line-clamp-1">
                            {isAr ? shot.titleAr || shot.title : shot.title}
                          </h5>

                          <p className="text-[11px] text-stone-400 line-clamp-3 leading-relaxed">
                            {isAr ? shot.visualPromptAr || shot.visualPrompt : shot.visualPrompt}
                          </p>

                          {shot.dialogue && (
                            <div className="p-2 rounded bg-stone-900/90 border border-stone-800 text-[11px] text-amber-200 flex items-start justify-between gap-2">
                              <div>
                                <span className="font-bold text-amber-400">{shot.dialogue.speakerName}: </span>
                                <span>{isAr ? shot.dialogue.textAr : shot.dialogue.text}</span>
                              </div>
                              <button
                                onClick={() => handleTestDialogueSpeech(isAr ? shot.dialogue!.textAr : shot.dialogue!.text, isAr ? 'ar' : 'en')}
                                className="p-1 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-amber-300 shrink-0"
                                title={isAr ? 'نطق الحوار' : 'Speak Dialogue'}
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="p-2 bg-stone-900/60 border-t border-stone-800/80 flex items-center justify-between text-[10px] text-stone-400">
                        <span>💡 {shot.lightingStyle.slice(0, 24)}...</span>
                        <span className="font-mono text-amber-400">{shot.focalLength}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
