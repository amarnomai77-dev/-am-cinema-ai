/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Character Consistency System (تثبيت الشخصيات)
 * Consistent Face, Wardrobe, Palette & Visual Tokens
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Sparkles,
  Camera,
  RefreshCw,
  Upload,
  Check,
  AlertCircle,
  Copy,
  Trash2,
  Edit2,
  ShieldCheck,
  Eye,
} from 'lucide-react';
import { CinemaProject, Character } from '../types/cinema';
import { cinemaAudio } from '../utils/audioPlayer';

interface CharacterCastViewProps {
  project: CinemaProject;
  onUpdateProject: (updated: CinemaProject) => void;
  lang: 'ar' | 'en';
}

export const CharacterCastView: React.FC<CharacterCastViewProps> = ({
  project,
  onUpdateProject,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingChar, setEditingChar] = useState<Character | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [role, setRole] = useState('Protagonist');
  const [age, setAge] = useState<number | string>(32);
  const [gender, setGender] = useState('Male');
  const [facialFeatures, setFacialFeatures] = useState('');
  const [wardrobe, setWardrobe] = useState('');
  const [signatureColors, setSignatureColors] = useState(['#f59e0b', '#09090b']);
  const [accessories, setAccessories] = useState('');
  const [referenceImageUrl, setReferenceImageUrl] = useState('');
  const [consistencyPromptToken, setConsistencyPromptToken] = useState('');

  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGeneratingPortrait, setIsGeneratingPortrait] = useState(false);
  const [copiedTokenId, setCopiedTokenId] = useState<string | null>(null);

  // Consistency variations modal
  const [variationModalChar, setVariationModalChar] = useState<Character | null>(null);
  const [variationsList, setVariationsList] = useState<string[]>([]);
  const [isLoadingVariations, setIsLoadingVariations] = useState(false);

  const resetForm = () => {
    setName('');
    setNameAr('');
    setRole('Protagonist');
    setAge(30);
    setGender('Male');
    setFacialFeatures('');
    setWardrobe('');
    setSignatureColors(['#f59e0b', '#09090b']);
    setAccessories('');
    setReferenceImageUrl('');
    setConsistencyPromptToken('');
    setEditingChar(null);
  };

  const handleOpenEdit = (char: Character) => {
    setEditingChar(char);
    setName(char.name);
    setNameAr(char.nameAr);
    setRole(char.role);
    setAge(char.age);
    setGender(char.gender);
    setFacialFeatures(char.facialFeatures);
    setWardrobe(char.wardrobe);
    setSignatureColors(char.signatureColors || ['#f59e0b']);
    setAccessories(char.accessories || '');
    setReferenceImageUrl(char.referenceImageUrl || '');
    setConsistencyPromptToken(char.consistencyPromptToken || '');
    setShowAddModal(true);
  };

  const handleEnhanceToken = async () => {
    if (!name.trim()) return;
    setIsEnhancing(true);
    cinemaAudio.playCinematicSound('drone');

    try {
      const res = await fetch('/api/character/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          role,
          age,
          gender,
          facialFeatures,
          wardrobe,
          signatureColors,
        }),
      });

      const data = await res.json();
      if (res.ok && data.consistencyToken) {
        setConsistencyPromptToken(data.consistencyToken);
        cinemaAudio.playCinematicSound('bell');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleGeneratePortrait = async () => {
    if (!name.trim()) return;
    setIsGeneratingPortrait(true);
    cinemaAudio.playCinematicSound('drone');

    try {
      const prompt = `Cinematic character portrait of ${name}, ${age} years old ${gender}, ${facialFeatures}, wearing ${wardrobe}, luxury lighting, 8k masterpiece, photorealistic, 35mm photograph`;
      const res = await fetch('/api/generate/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          provider: 'pollinations-free',
          aspectRatio: '1:1',
        }),
      });

      const data = await res.json();
      if (res.ok && data.imageUrl) {
        setReferenceImageUrl(data.imageUrl);
        cinemaAudio.playCinematicSound('bell');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingPortrait(false);
    }
  };

  const handleSaveCharacter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const token =
      consistencyPromptToken ||
      `char_${name.toLowerCase().replace(/\s+/g, '_')}: ${age}yo ${gender}, ${facialFeatures}, wearing ${wardrobe}, palette ${signatureColors.join(', ')}`;

    let updatedList: Character[];

    if (editingChar) {
      updatedList = project.characters.map((c) =>
        c.id === editingChar.id
          ? {
              ...c,
              name,
              nameAr: nameAr || name,
              role,
              age,
              gender,
              facialFeatures,
              wardrobe,
              signatureColors,
              accessories,
              referenceImageUrl,
              consistencyPromptToken: token,
            }
          : c
      );
    } else {
      const newChar: Character = {
        id: `char_${Date.now()}`,
        name,
        nameAr: nameAr || name,
        role,
        age,
        gender,
        ethnicityOrStyle: '',
        facialFeatures,
        wardrobe,
        signatureColors,
        accessories,
        referenceImageUrl:
          referenceImageUrl ||
          `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80`,
        consistencyPromptToken: token,
        createdAt: Date.now(),
      };
      updatedList = [...project.characters, newChar];
    }

    onUpdateProject({
      ...project,
      characters: updatedList,
      updatedAt: Date.now(),
    });

    setShowAddModal(false);
    resetForm();
    cinemaAudio.playCinematicSound('click');
  };

  const handleDeleteCharacter = (charId: string) => {
    if (confirm(isAr ? 'هل أنت متأكد من حذف هذه الشخصية من طاقم الفيلم؟' : 'Delete character from cast?')) {
      const updated = project.characters.filter((c) => c.id !== charId);
      onUpdateProject({ ...project, characters: updated, updatedAt: Date.now() });
    }
  };

  const handleCopyToken = (char: Character) => {
    navigator.clipboard.writeText(char.consistencyPromptToken);
    setCopiedTokenId(char.id);
    setTimeout(() => setCopiedTokenId(null), 2000);
    cinemaAudio.playCinematicSound('click');
  };

  const handleInspectVariations = async (char: Character) => {
    setVariationModalChar(char);
    setIsLoadingVariations(true);

    try {
      const baseToken = char.consistencyPromptToken;
      const angles = [
        `Cinematic close-up portrait, ${baseToken}, dramatic rim lighting, shallow depth of field`,
        `Wide establishing shot, ${baseToken}, walking through cinematic environment, wind in hair, epic atmosphere`,
        `Medium action shot, ${baseToken}, intense dramatic confrontation, dynamic camera angle, 35mm film`,
        `Low-key chiaroscuro lighting shot, ${baseToken}, contemplative emotional expression, deep shadows, 8k masterpiece`,
      ];

      // Fetch preview images for these variations
      const urls = angles.map((ang, idx) =>
        `https://image.pollinations.ai/prompt/${encodeURIComponent(ang)}?width=600&height=600&seed=${char.id.length * 100 + idx * 37}&nologo=true`
      );

      setVariationsList(urls);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingVariations(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'نظام ثبات ملامح الشخصيات عبر المشاهد' : 'Character Consistency Architecture'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'طاقم الشخصيات والتوكن البصري الموحد' : 'Character Cast & Consistency Anchors'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1 max-w-2xl">
            {isAr
              ? 'يضمن هذا النظام ظهور الممثل أو الشخصية بنفس الوجه، والملابس، والألوان في جميع لقطات الفيلم المتعاقبة دون أي تشويه أو تغيير عشوائي.'
              : 'Ensures characters maintain identical facial architecture, wardrobe, and color palettes across multiple distinct scenes.'}
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-xs bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-lg shadow-amber-500/20 transition transform hover:scale-[1.02]"
        >
          <UserPlus className="w-4 h-4 stroke-[3]" />
          <span>{isAr ? 'إضافة شخصية جديدة' : 'Add Character'}</span>
        </button>
      </div>

      {/* Characters Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {project.characters.map((char) => (
          <div
            key={char.id}
            className="rounded-2xl bg-[#0c0c10] border border-stone-800 hover:border-amber-500/40 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-xl group"
          >
            <div>
              {/* Reference Image Header */}
              <div className="relative h-56 w-full bg-stone-900 overflow-hidden">
                {char.referenceImageUrl ? (
                  <img
                    src={char.referenceImageUrl}
                    alt={char.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-500">
                    <Users className="w-12 h-12" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c10] via-transparent to-black/60" />

                <div className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-black/80 backdrop-blur-sm border border-stone-700 text-[11px] text-amber-300 font-bold">
                  {char.role}
                </div>

                <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white drop-shadow">
                      {isAr ? char.nameAr || char.name : char.name}
                    </h3>
                    <p className="text-xs text-amber-400 font-medium">
                      {char.age} {isAr ? 'سنة' : 'y/o'} • {char.gender}
                    </p>
                  </div>

                  {/* Signature Colors Chips */}
                  <div className="flex items-center gap-1">
                    {char.signatureColors?.map((c, i) => (
                      <span
                        key={i}
                        className="w-4 h-4 rounded-full border border-white/40 shadow-sm"
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Character Details Body */}
              <div className="p-4 space-y-3">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">
                    {isAr ? 'ملامح الوجه:' : 'Facial Structure:'}
                  </span>
                  <p className="text-xs text-stone-300 line-clamp-2 leading-relaxed">
                    {char.facialFeatures || (isAr ? 'ملامح سينمائية مميزة' : 'Cinematic facial details')}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">
                    {isAr ? 'الملابس المعتمدة:' : 'Wardrobe & Costume:'}
                  </span>
                  <p className="text-xs text-stone-300 line-clamp-2 leading-relaxed">
                    {char.wardrobe || (isAr ? 'زي سينمائي متسق' : 'Cinematic attire')}
                  </p>
                </div>

                {/* Consistency Token Box */}
                <div className="p-2.5 rounded-lg bg-stone-950 border border-stone-800 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-amber-400 font-semibold">
                    <span>{isAr ? 'توكن الثبات البصري (Consistency Token):' : 'Consistency Anchor Token:'}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyToken(char)}
                      className="hover:text-white flex items-center gap-1 text-[10px]"
                      title={isAr ? 'نسخ التوكن' : 'Copy'}
                    >
                      {copiedTokenId === char.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedTokenId === char.id ? (isAr ? 'تم النسخ' : 'Copied') : (isAr ? 'نسخ' : 'Copy')}</span>
                    </button>
                  </div>
                  <p className="text-[11px] font-mono text-stone-300 line-clamp-2 select-all">
                    {char.consistencyPromptToken}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions Footer */}
            <div className="p-3 bg-stone-950/70 border-t border-stone-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleInspectVariations(char)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 transition"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>{isAr ? 'اختبار الثبات في 4 زوايا' : 'Inspect 4 Angles'}</span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleOpenEdit(char)}
                  className="p-1.5 rounded hover:bg-stone-800 text-stone-400 hover:text-amber-300 transition"
                  title={isAr ? 'تعديل' : 'Edit'}
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteCharacter(char.id)}
                  className="p-1.5 rounded hover:bg-rose-950/50 text-stone-400 hover:text-rose-400 transition"
                  title={isAr ? 'حذف' : 'Delete'}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Character Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0e0e13] border border-amber-500/30 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <span>
                  {editingChar
                    ? isAr ? 'تعديل بيانات الشخصية والتوكن' : 'Edit Character Anchor'
                    : isAr ? 'إضافة شخصية جديدة لطاقم العمل' : 'Add New Cast Character'}
                </span>
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  resetForm();
                }}
                className="text-stone-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCharacter} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'الاسم بالإنجليزية:' : 'Character Name (English):'}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Commander Tareq"
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'الاسم بالعربية:' : 'Character Name (Arabic):'}
                  </label>
                  <input
                    type="text"
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                    placeholder="مثال: القائد طارق"
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">{isAr ? 'الدور الدرامي:' : 'Role:'}</label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">{isAr ? 'العمر التقريبي:' : 'Age:'}</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">{isAr ? 'الجنس:' : 'Gender:'}</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  >
                    <option value="Male">Male (ذكر)</option>
                    <option value="Female">Female (أنثى)</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Facial features */}
              <div className="space-y-1">
                <label className="text-xs text-stone-300 font-medium">
                  {isAr ? 'ملامح الوجه الدقيقة (لضمان الثبات عبر المحركات):' : 'Facial Structure & Features:'}
                </label>
                <textarea
                  rows={2}
                  value={facialFeatures}
                  onChange={(e) => setFacialFeatures(e.target.value)}
                  placeholder="e.g. Sharp jawline, piercing amber eyes, trimmed beard with gray touches, prominent brow"
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none leading-relaxed"
                />
              </div>

              {/* Wardrobe */}
              <div className="space-y-1">
                <label className="text-xs text-stone-300 font-medium">
                  {isAr ? 'الملابس وخامات الأزياء والألوان:' : 'Wardrobe, Cut & Fabrics:'}
                </label>
                <textarea
                  rows={2}
                  value={wardrobe}
                  onChange={(e) => setWardrobe(e.target.value)}
                  placeholder="e.g. Heavy charcoal wool coat with bronze brass buttons, obsidian turtleneck, weathered leather belt"
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none leading-relaxed"
                />
              </div>

              {/* Token Builder with AI button */}
              <div className="space-y-2 border-t border-stone-800 pt-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-amber-300">
                    {isAr ? 'توكن الثبات البصري المولد:' : 'Consistency Anchor Token:'}
                  </label>
                  <button
                    type="button"
                    disabled={isEnhancing}
                    onClick={handleEnhanceToken}
                    className="flex items-center gap-1.5 px-3 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold transition"
                  >
                    {isEnhancing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                    <span>{isAr ? 'توليد بالذكاء الاصطناعي (Gemini)' : 'Optimize with Gemini'}</span>
                  </button>
                </div>

                <input
                  type="text"
                  value={consistencyPromptToken}
                  onChange={(e) => setConsistencyPromptToken(e.target.value)}
                  placeholder="[char_token: facial traits, clothes, palette]"
                  className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-800 focus:border-amber-500 text-amber-200 font-mono text-xs outline-none"
                />
              </div>

              {/* Reference portrait preview & generator */}
              <div className="space-y-2 border-t border-stone-800 pt-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'الصورة المرجعية للشخصية:' : 'Reference Portrait Image:'}
                  </label>
                  <button
                    type="button"
                    disabled={isGeneratingPortrait}
                    onClick={handleGeneratePortrait}
                    className="flex items-center gap-1.5 px-3 py-1 rounded bg-stone-900 hover:bg-stone-800 text-amber-300 border border-stone-700 text-xs transition"
                  >
                    {isGeneratingPortrait ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
                    <span>{isAr ? 'توليد بورتريه فوري' : 'Generate Portrait'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={referenceImageUrl}
                    onChange={(e) => setReferenceImageUrl(e.target.value)}
                    placeholder="https://... or upload"
                    className="flex-1 px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-200 text-xs outline-none"
                  />
                  {referenceImageUrl && (
                    <img src={referenceImageUrl} alt="preview" className="w-9 h-9 rounded object-cover border border-amber-500/50" />
                  )}
                </div>
              </div>

              {/* Modal buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    resetForm();
                  }}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-stone-400 hover:text-white"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-md shadow-amber-500/20"
                >
                  {isAr ? 'حفظ واعتماد الشخصية' : 'Save Character'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4-Angles Consistency Inspection Modal */}
      {variationModalChar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0e0e13] border border-amber-500/40 rounded-2xl w-full max-w-3xl p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                  <Eye className="w-5 h-5 text-amber-400" />
                  <span>{isAr ? 'فحص ثبات الملامح في 4 زوايا وإضاءات مختلفة' : '4-Angle Consistency Test'}</span>
                </h3>
                <p className="text-xs text-stone-400">
                  {isAr ? variationModalChar.nameAr || variationModalChar.name : variationModalChar.name} — {variationModalChar.role}
                </p>
              </div>
              <button
                onClick={() => setVariationModalChar(null)}
                className="text-stone-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {isLoadingVariations ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-stone-400 text-xs">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
                <span>{isAr ? 'جاري فحص الثبات وتوليد الزوايا الأربع...' : 'Generating 4 test angles...'}</span>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {variationsList.map((url, idx) => (
                  <div key={idx} className="rounded-xl overflow-hidden bg-black border border-stone-800 space-y-1">
                    <img src={url} alt={`angle ${idx}`} className="w-full aspect-square object-cover" />
                    <p className="p-2 text-[10px] text-stone-400 text-center font-mono">
                      {idx === 0
                        ? isAr ? 'بورتريه مقرب' : 'Close-Up'
                        : idx === 1
                        ? isAr ? 'لقطة واسعة' : 'Wide Angle'
                        : idx === 2
                        ? isAr ? 'لقطة حركة' : 'Action Shot'
                        : isAr ? 'إضاءة ظلال' : 'Chiaroscuro'}
                    </p>
                  </div>
                ))}
              </div>
            )}

            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                {isAr
                  ? 'يتم استخدام نفس توكن الثبات البصري في كافة محركات التوليد لضمان تماسك الملامح بنسبة تتجاوز 90%.'
                  : 'The consistency anchor token locks facial geometry and color palette across all multi-shot generations.'}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
