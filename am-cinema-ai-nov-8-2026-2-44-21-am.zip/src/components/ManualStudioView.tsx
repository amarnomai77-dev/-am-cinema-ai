/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Manual Studio Mode (الوضع اليدوي)
 * Direct Shot Crafting, Camera Movement & Motion Control
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Camera,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  RefreshCw,
  Image as ImageIcon,
  Upload,
  Volume2,
  Video,
  Eye,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  Move,
  Maximize2,
  Layers,
} from 'lucide-react';
import {
  CinemaProject,
  Shot,
  CameraMovementType,
  ShotFramingType,
  VideoResolution,
  TransitionType,
} from '../types/cinema';
import { cinemaAudio } from '../utils/audioPlayer';

interface ManualStudioViewProps {
  project: CinemaProject;
  onUpdateProject: (updated: CinemaProject) => void;
  lang: 'ar' | 'en';
}

export const ManualStudioView: React.FC<ManualStudioViewProps> = ({
  project,
  onUpdateProject,
  lang,
}) => {
  const isAr = lang === 'ar';

  // Gather all shots flattened
  const allShotsWithScene = project.scenes.flatMap((sc) =>
    sc.shots.map((sh) => ({ ...sh, sceneNumber: sc.sceneNumber, sceneTitle: sc.title }))
  );

  const [selectedShotId, setSelectedShotId] = useState<string>(
    allShotsWithScene[0]?.id || ''
  );

  // Active shot
  const activeShot = allShotsWithScene.find((s) => s.id === selectedShotId) || allShotsWithScene[0];

  const [prompt, setPrompt] = useState(activeShot?.visualPrompt || '');
  const [promptAr, setPromptAr] = useState(activeShot?.visualPromptAr || '');
  const [negativePrompt, setNegativePrompt] = useState(activeShot?.negativePrompt || '');
  const [cameraMovement, setCameraMovement] = useState<CameraMovementType>(
    activeShot?.cameraMovement || 'zoom_in'
  );
  const [framing, setFraming] = useState<ShotFramingType>(activeShot?.framing || 'medium_shot');
  const [focalLength, setFocalLength] = useState(activeShot?.focalLength || '35mm');
  const [motionStrength, setMotionStrength] = useState(activeShot?.motionStrength || 5);
  const [duration, setDuration] = useState(activeShot?.durationSeconds || 4);
  const [resolution, setResolution] = useState<VideoResolution>(activeShot?.resolution || '1080p');
  const [transition, setTransition] = useState<TransitionType>(activeShot?.transitionToNext || 'crossfade');
  const [lighting, setLighting] = useState(activeShot?.lightingStyle || 'Dramatic golden hour');
  const [engine, setEngine] = useState('pollinations-free');

  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Camera preview animation
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  const [previewProgress, setPreviewProgress] = useState(0);
  const animRef = useRef<number | null>(null);

  // Sync state when active shot changes
  useEffect(() => {
    if (activeShot) {
      setPrompt(activeShot.visualPrompt || '');
      setPromptAr(activeShot.visualPromptAr || '');
      setNegativePrompt(activeShot.negativePrompt || '');
      setCameraMovement(activeShot.cameraMovement || 'zoom_in');
      setFraming(activeShot.framing || 'medium_shot');
      setFocalLength(activeShot.focalLength || '35mm');
      setMotionStrength(activeShot.motionStrength || 5);
      setDuration(activeShot.durationSeconds || 4);
      setResolution(activeShot.resolution || '1080p');
      setTransition(activeShot.transitionToNext || 'crossfade');
      setLighting(activeShot.lightingStyle || 'Dramatic golden hour');
      setPreviewProgress(0);
      setIsPreviewPlaying(false);
    }
  }, [selectedShotId]);

  // Handle camera preview animation loop
  useEffect(() => {
    if (!isPreviewPlaying) {
      if (animRef.current) cancelAnimationFrame(animRef.current);
      return;
    }

    const startTime = performance.now();
    const durationMs = duration * 1000;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1.0, elapsed / durationMs);
      setPreviewProgress(progress);

      if (progress < 1.0) {
        animRef.current = requestAnimationFrame(tick);
      } else {
        setIsPreviewPlaying(false);
      }
    };

    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isPreviewPlaying, duration]);

  // Save changes to active shot in project
  const saveShotChanges = (overrides?: Partial<Shot>) => {
    if (!activeShot) return;

    const updatedScenes = project.scenes.map((sc) => ({
      ...sc,
      shots: sc.shots.map((sh) => {
        if (sh.id === activeShot.id) {
          return {
            ...sh,
            visualPrompt: prompt,
            visualPromptAr: promptAr,
            negativePrompt,
            cameraMovement,
            framing,
            focalLength,
            motionStrength,
            durationSeconds: duration,
            resolution,
            transitionToNext: transition,
            lightingStyle: lighting,
            ...overrides,
          };
        }
        return sh;
      }),
    }));

    const totalSecs = updatedScenes.reduce(
      (acc, sc) => acc + sc.shots.reduce((shAcc, sh) => shAcc + (sh.durationSeconds || 4), 0),
      0
    );

    onUpdateProject({
      ...project,
      scenes: updatedScenes,
      totalDurationSeconds: totalSecs,
      updatedAt: Date.now(),
    });
  };

  const handleInjectCharacter = (charToken: string) => {
    setPrompt((prev) => `${charToken}, ${prev}`);
    cinemaAudio.playCinematicSound('click');
  };

  const handleGenerateKeyframe = async () => {
    if (!prompt.trim()) {
      setErrorMsg(isAr ? 'يرجى كتابة وصف اللقطة أولاً' : 'Prompt is required');
      return;
    }

    setIsGenerating(true);
    setStatusMsg(isAr ? 'جاري توليد اللقطة السينمائية...' : 'Generating cinematic keyframe...');
    setErrorMsg(null);
    cinemaAudio.playCinematicSound('drone');

    try {
      const res = await fetch('/api/generate/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          negativePrompt,
          provider: engine,
          aspectRatio: project.settings.aspectRatio,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate shot');
      }

      saveShotChanges({ imageUrl: data.imageUrl, providerUsed: data.provider });
      setStatusMsg(isAr ? 'تم توليد واعتماد اللقطة بنجاح!' : 'Keyframe generated successfully!');
      cinemaAudio.playCinematicSound('bell');
    } catch (err: any) {
      setErrorMsg(err.message || 'Generation failed');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const url = event.target?.result as string;
      saveShotChanges({ imageUrl: url });
      setStatusMsg(isAr ? 'تم رفع الصورة المرجعية بنجاح' : 'Reference image loaded');
      cinemaAudio.playCinematicSound('click');
    };
    reader.readAsDataURL(file);
  };

  // Calculate transform styles based on cameraMovement and previewProgress
  const getCameraTransform = () => {
    const strength = (motionStrength || 5) / 10;
    const p = isPreviewPlaying ? previewProgress : 0.5;

    switch (cameraMovement) {
      case 'zoom_in':
        return { transform: `scale(${1.0 + p * 0.25 * strength})` };
      case 'zoom_out':
        return { transform: `scale(${1.25 - p * 0.25 * strength})` };
      case 'pan_left':
        return { transform: `scale(1.15) translateX(${-p * 60 * strength}px)` };
      case 'pan_right':
        return { transform: `scale(1.15) translateX(${p * 60 * strength}px)` };
      case 'tilt_up':
        return { transform: `scale(1.15) translateY(${-p * 50 * strength}px)` };
      case 'tilt_down':
        return { transform: `scale(1.15) translateY(${p * 50 * strength}px)` };
      case 'camera_tracking':
      case 'orbit_360':
      case 'crane_shot':
        return {
          transform: `scale(${1.08 + Math.sin(p * Math.PI) * 0.15 * strength}) translateX(${Math.cos(p * Math.PI) * 30 * strength}px)`,
        };
      default:
        return { transform: 'scale(1.03)' };
    }
  };

  const CAMERA_MOVEMENTS: { id: CameraMovementType; labelAr: string; labelEn: string; icon: string }[] = [
    { id: 'zoom_in', labelAr: 'تقريب للداخل (Zoom In)', labelEn: 'Zoom In', icon: '🔍+' },
    { id: 'zoom_out', labelAr: 'تبعيد للخارج (Zoom Out)', labelEn: 'Zoom Out', icon: '🔍-' },
    { id: 'pan_left', labelAr: 'تحريك لليسار (Pan Left)', labelEn: 'Pan Left', icon: '⬅️' },
    { id: 'pan_right', labelAr: 'تحريك لليمين (Pan Right)', labelEn: 'Pan Right', icon: '➡️' },
    { id: 'tilt_up', labelAr: 'إمالة للأعلى (Tilt Up)', labelEn: 'Tilt Up', icon: '⬆️' },
    { id: 'tilt_down', labelAr: 'إمالة للأسفل (Tilt Down)', labelEn: 'Tilt Down', icon: '⬇️' },
    { id: 'camera_tracking', labelAr: 'تتبع الكاميرا (Dolly Tracking)', labelEn: 'Camera Tracking', icon: '🎥' },
    { id: 'orbit_360', labelAr: 'دوران مداري (Orbit 360)', labelEn: 'Orbit 360', icon: '🔄' },
    { id: 'crane_shot', labelAr: 'رافعة سينمائية (Crane Shot)', labelEn: 'Crane Shot', icon: '🏗️' },
    { id: 'static_tripod', labelAr: 'حامل ثابت (Static Tripod)', labelEn: 'Static', icon: '📷' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-1">
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'الوضع اليدوي — استوديو اللقطات' : 'Manual Studio — Shot Crafting'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Camera className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'غرفة التحكم بحركة الكاميرا واللقطات' : 'Camera Motion & Shot Studio'}</span>
          </h2>
        </div>

        {/* Shot Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-stone-400 font-medium">{isAr ? 'اللقطة:' : 'Shot:'}</label>
          <select
            value={selectedShotId}
            onChange={(e) => setSelectedShotId(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-amber-300 text-xs font-bold outline-none focus:border-amber-500"
          >
            {allShotsWithScene.map((sh, idx) => (
              <option key={sh.id} value={sh.id}>
                #{sh.shotNumber} - {isAr ? sh.titleAr || sh.title : sh.title} ({sh.durationSeconds}s)
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Camera Viewport & Motion Simulator */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-200 flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-amber-400" />
                <span>{isAr ? 'معاينة محاكاة الكاميرا' : 'Live Camera Motion Viewport'}</span>
              </span>

              <span className="text-[11px] font-mono text-amber-400 font-bold px-2 py-0.5 rounded bg-black/60 border border-stone-800">
                {resolution} • {duration}s
              </span>
            </div>

            {/* Viewport Frame with Cinemascope or Widescreen */}
            <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-black border border-stone-800 shadow-2xl flex items-center justify-center">
              {activeShot?.imageUrl ? (
                <div
                  className="w-full h-full transition-transform duration-75 ease-out origin-center"
                  style={getCameraTransform()}
                >
                  <img
                    src={activeShot.imageUrl}
                    alt={activeShot.title}
                    className="w-full h-full object-cover pointer-events-none"
                  />
                </div>
              ) : (
                <div className="text-center p-4 space-y-2 text-stone-500">
                  <ImageIcon className="w-8 h-8 mx-auto text-stone-600" />
                  <p className="text-xs">{isAr ? 'لم يتم توليد صورة لهذه اللقطة بعد' : 'No keyframe image yet'}</p>
                </div>
              )}

              {/* Aspect Ratio Letterbox (Cinemascope 2.39:1 overlay) */}
              {project.settings.aspectRatio === '2.39:1' && (
                <>
                  <div className="absolute top-0 left-0 right-0 h-[12%] bg-[#070709] border-b border-amber-500/20 pointer-events-none" />
                  <div className="absolute bottom-0 left-0 right-0 h-[12%] bg-[#070709] border-t border-amber-500/20 pointer-events-none" />
                </>
              )}

              {/* Viewport HUD Overlays */}
              <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[10px] font-mono text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>REC [{cameraMovement.toUpperCase()}]</span>
              </div>

              <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[10px] font-mono text-stone-300 border border-stone-800">
                {focalLength} • {framing}
              </div>

              {/* Playhead scrub line when playing */}
              {isPreviewPlaying && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-stone-800">
                  <div
                    className="h-full bg-amber-400 transition-all duration-75"
                    style={{ width: `${previewProgress * 100}%` }}
                  />
                </div>
              )}
            </div>

            {/* Playback & Simulator Controls */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <button
                type="button"
                onClick={() => {
                  if (isPreviewPlaying) {
                    setIsPreviewPlaying(false);
                  } else {
                    setPreviewProgress(0);
                    setIsPreviewPlaying(true);
                    cinemaAudio.playCinematicSound('whoosh');
                  }
                }}
                className="flex-1 py-2 px-3 rounded-lg font-bold text-xs bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 flex items-center justify-center gap-2 transition"
              >
                {isPreviewPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>{isPreviewPlaying ? (isAr ? 'إيقاف المحاكاة' : 'Pause') : (isAr ? 'تشغيل حركة الكاميرا' : 'Play Camera Motion')}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPreviewProgress(0);
                  setIsPreviewPlaying(false);
                }}
                className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition"
                title={isAr ? 'إعادة التعيين' : 'Reset Position'}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              <label className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 cursor-pointer transition flex items-center gap-1 text-xs">
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">{isAr ? 'رفع صورة' : 'Upload'}</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>

          {/* Character Consistency Fast Inserter */}
          <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-4 space-y-2 shadow-xl">
            <h4 className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{isAr ? 'حقن ملامح الشخصية للثبات البصري:' : 'Inject Character Consistency Anchor:'}</span>
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {project.characters.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => handleInjectCharacter(c.consistencyPromptToken)}
                  className="px-2.5 py-1 rounded bg-stone-900 hover:bg-amber-500/20 border border-stone-800 hover:border-amber-500/40 text-[11px] text-amber-300 transition flex items-center gap-1"
                >
                  <span>+ {isAr ? c.nameAr || c.name : c.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Camera Choreography Controls & Prompts */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#0b0b10] border border-stone-800 rounded-xl p-5 space-y-5 shadow-xl">
            {/* Visual Prompt Section */}
            <div className="space-y-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-stone-200">
                    {isAr ? 'وصف اللقطة البصري (Prompt):' : 'Visual Scene Prompt (English):'}
                  </label>
                  <span className="text-[10px] text-stone-500">
                    {isAr ? 'موجّه لمحركات الفيديو والصور' : 'Optimized for Video/Image AI'}
                  </span>
                </div>
                <textarea
                  rows={3}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs leading-relaxed outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-stone-400">
                  {isAr ? 'الوصف بالعربية (للتوثيق والحوار):' : 'Arabic Scene Description:'}
                </label>
                <input
                  type="text"
                  value={promptAr}
                  onChange={(e) => setPromptAr(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-stone-950 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                />
              </div>
            </div>

            {/* Camera Movement Grid */}
            <div className="space-y-2 border-t border-stone-800 pt-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <Move className="w-3.5 h-3.5" />
                  <span>{isAr ? 'حركة الكاميرا السينمائية:' : 'Cinematic Camera Movement:'}</span>
                </label>
                <span className="text-[11px] text-stone-400 font-mono">{cameraMovement}</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {CAMERA_MOVEMENTS.map((cm) => {
                  const isSelected = cameraMovement === cm.id;
                  return (
                    <button
                      key={cm.id}
                      type="button"
                      onClick={() => {
                        setCameraMovement(cm.id);
                        cinemaAudio.playCinematicSound('click');
                      }}
                      className={`p-2 rounded-lg border text-left text-xs transition flex flex-col items-center justify-center gap-1 ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-md shadow-amber-500/10'
                          : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700'
                      }`}
                    >
                      <span className="text-base">{cm.icon}</span>
                      <span className="text-[10px] text-center line-clamp-1">{isAr ? cm.labelAr.split('(')[0] : cm.labelEn}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dials: Motion Strength, Focal Length, Duration, Resolution */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-stone-800 pt-4">
              {/* Motion Strength */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-400 font-medium">
                  <span>{isAr ? 'قوة الحركة:' : 'Motion Power:'}</span>
                  <span className="text-amber-400 font-mono">{motionStrength}/10</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={motionStrength}
                  onChange={(e) => setMotionStrength(parseInt(e.target.value, 10))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              {/* Shot Duration */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-400 font-medium">
                  <span>{isAr ? 'مدة اللقطة:' : 'Duration:'}</span>
                  <span className="text-amber-400 font-mono">{duration}s</span>
                </div>
                <input
                  type="range"
                  min={2}
                  max={15}
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value, 10))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              {/* Focal Length */}
              <div className="space-y-1">
                <label className="text-xs text-stone-400 font-medium">
                  {isAr ? 'البُعد البؤري:' : 'Focal Length:'}
                </label>
                <select
                  value={focalLength}
                  onChange={(e) => setFocalLength(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs outline-none"
                >
                  <option value="24mm">24mm (Wide Establishing)</option>
                  <option value="35mm">35mm (Natural Cinematic)</option>
                  <option value="50mm">50mm (Human Eye Standard)</option>
                  <option value="85mm">85mm (Portrait / Close-up)</option>
                  <option value="135mm">135mm (Telephoto Compression)</option>
                </select>
              </div>

              {/* Video Resolution */}
              <div className="space-y-1">
                <label className="text-xs text-stone-400 font-medium">
                  {isAr ? 'جودة الفيديو:' : 'Resolution:'}
                </label>
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as VideoResolution)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs outline-none"
                >
                  <option value="360p">360p (Preview Ultra-Fast)</option>
                  <option value="480p">480p (Fast)</option>
                  <option value="720p">720p (HD)</option>
                  <option value="1080p">1080p (Full HD Master)</option>
                  <option value="2K">2K (Cinema DCI)</option>
                  <option value="4K">4K (Ultra HD)</option>
                </select>
              </div>
            </div>

            {/* AI Engine & Generate Action */}
            <div className="border-t border-stone-800 pt-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-stone-400 font-medium">
                    {isAr ? 'المحرك المتصل:' : 'AI Engine:'}
                  </label>
                  <select
                    value={engine}
                    onChange={(e) => setEngine(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-amber-300 text-xs outline-none font-medium"
                  >
                    <option value="pollinations-free">Pollinations (Open Free Cinema)</option>
                    <option value="gemini-cinema">Gemini Core (Google)</option>
                    <option value="runway-gen3">Runway Gen-3 (Motion Video)</option>
                    <option value="luma-dream">Luma Dream Machine</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() => saveShotChanges()}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-700 transition"
                >
                  {isAr ? 'حفظ إعدادات اللقطة' : 'Save Shot Parameters'}
                </button>
              </div>

              {/* Status / Error feedback */}
              {statusMsg && (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{statusMsg}</span>
                </div>
              )}
              {errorMsg && (
                <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Generate Keyframe Button */}
              <button
                type="button"
                disabled={isGenerating}
                onClick={handleGenerateKeyframe}
                className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                  isGenerating
                    ? 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-stone-950 shadow-amber-500/20'
                }`}
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                    <span>{isAr ? 'جاري توليد اللقطة بدقة عالية...' : 'Generating Keyframe...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 fill-current" />
                    <span>{isAr ? 'توليد اللقطة السينمائية واعتمادها' : 'Render & Approve Keyframe'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
