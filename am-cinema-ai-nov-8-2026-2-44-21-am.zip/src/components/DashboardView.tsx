/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Dashboard & Project Manager
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState } from 'react';
import {
  Film,
  Plus,
  Play,
  Clock,
  Sparkles,
  Download,
  Upload,
  Copy,
  Trash2,
  DollarSign,
  Layers,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
} from 'lucide-react';
import { CinemaProject, AspectRatio, VideoResolution } from '../types/cinema';
import { STARTER_CHARACTERS } from '../utils/storage';

interface DashboardViewProps {
  projects: CinemaProject[];
  currentProjectId: string;
  onSelectProject: (id: string) => void;
  onCreateProject: (newProj: CinemaProject) => void;
  onDuplicateProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onImportProject: (imported: CinemaProject) => void;
  onNavigateTab: (tab: any) => void;
  lang: 'ar' | 'en';
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  projects,
  currentProjectId,
  onSelectProject,
  onCreateProject,
  onDuplicateProject,
  onDeleteProject,
  onImportProject,
  onNavigateTab,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTitleAr, setNewTitleAr] = useState('');
  const [newGenre, setNewGenre] = useState('Cinematic Sci-Fi');
  const [newSynopsis, setNewSynopsis] = useState('');
  const [newAspectRatio, setNewAspectRatio] = useState<AspectRatio>('2.39:1');
  const [newResolution, setNewResolution] = useState<VideoResolution>('1080p');

  // Calculate global stats
  const totalShots = projects.reduce(
    (acc, p) => acc + p.scenes.reduce((scAcc, sc) => scAcc + sc.shots.length, 0),
    0
  );
  const totalSeconds = projects.reduce((acc, p) => acc + (p.totalDurationSeconds || 0), 0);
  const totalCost = projects.reduce((acc, p) => acc + (p.estimatedCostUsd || 0), 0);

  const PRESETS = [
    {
      titleEn: 'Neo-Riyadh 2099',
      titleAr: 'فجر الرياض السيبراني 2099',
      genre: 'Cyberpunk Neon Noir',
      synopsis: 'A cyber-archaeologist in towering futuristic Riyadh uncovers an ancient holographic codex that awakens dormant desert satellites.',
      aspectRatio: '2.39:1' as AspectRatio,
    },
    {
      titleEn: 'Echoes of Andalusia',
      titleAr: 'أصداء الأندلس المفقودة',
      genre: 'Historical Epic / Panavision',
      synopsis: 'In medieval Cordoba, an optical scientist and an astrologer build a magical prism that captures voices from the celestial spheres.',
      aspectRatio: '2.39:1' as AspectRatio,
    },
    {
      titleEn: 'Orbital Horizon',
      titleAr: 'أفق المدار الخارق',
      genre: 'Hard Sci-Fi / Deep Space',
      synopsis: 'The last deep-space salvage vessel discovers an abandoned alien star-ring orbiting Jupiter, triggering a leap into another galaxy.',
      aspectRatio: '16:9' as AspectRatio,
    },
  ];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newProj: CinemaProject = {
      id: `proj_${Date.now()}`,
      title: newTitle,
      titleAr: newTitleAr || newTitle,
      logline: newSynopsis.slice(0, 120),
      loglineAr: newSynopsis.slice(0, 120),
      synopsis: newSynopsis || 'A compelling new cinematic vision by AMMAR ALNAMI.',
      synopsisAr: newSynopsis || 'رؤية سينمائية متفردة تم إنتاجها بواسطة عمار النمي.',
      owner: 'AMMAR ALNAMI — عمار النمي',
      settings: {
        aspectRatio: newAspectRatio,
        defaultResolution: newResolution,
        targetDurationSeconds: 120,
        genre: newGenre,
        visualStyle: '35mm Film Panavision, Warm Gold & Deep Shadow',
        filmColorPalette: ['#f59e0b', '#78350f', '#09090b', '#38bdf8'],
      },
      characters: [...STARTER_CHARACTERS],
      scenes: [],
      totalDurationSeconds: 0,
      estimatedCostUsd: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onCreateProject(newProj);
    setShowCreateModal(false);
    setNewTitle('');
    setNewTitleAr('');
    setNewSynopsis('');
  };

  const handleExportJSON = (project: CinemaProject) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${project.title.replace(/\s+/g, '_')}_AM_CINEMA.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.id && parsed.title && parsed.scenes) {
          onImportProject(parsed);
        } else {
          alert(isAr ? 'ملف المشروع غير صالح أو ناقص' : 'Invalid cinema project file');
        }
      } catch (err) {
        alert(isAr ? 'فشل قراءة الملف' : 'Failed to parse JSON file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Studio Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-stone-950 via-[#0e0e14] to-stone-950 border border-amber-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{isAr ? 'منصة صناعة الأفلام المستقلة' : 'Autonomous AI Film Studio'}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white font-cinematic">
              AM CINEMA AI
            </h1>
            <p className="text-sm sm:text-base text-stone-300 leading-relaxed">
              {isAr
                ? 'استوديو الإخراج السينمائي المتكامل المطور بواسطة عمار النمي — تجربة تصوير وإنتاج مستوحاة من Google Flow بأعلى معايير جودة الصورة وحركات الكاميرا وثبات الشخصيات.'
                : 'The complete cinematic production platform by AMMAR ALNAMI — inspired by the Google Flow experience with camera movement choreography and character consistency.'}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-amber-400/90">
              <span className="font-semibold">{isAr ? 'المطور الرئيسي:' : 'Lead Developer:'} AMMAR ALNAMI — عمار النمي</span>
              <span>•</span>
              <span>AI Assistant: ChatGPT (GT Assistant)</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-stone-950 shadow-lg shadow-amber-500/25 transition-all transform hover:scale-[1.02]"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{isAr ? 'إنتاج فيلم جديد' : 'New Cinema Project'}</span>
            </button>

            <label className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 cursor-pointer transition">
              <Upload className="w-4 h-4 text-amber-400" />
              <span>{isAr ? 'استيراد مشروع' : 'Import JSON'}</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>
          </div>
        </div>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0c0c10] border border-stone-800/80 shadow-lg flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-stone-400">{isAr ? 'إجمالي المشاريع' : 'Total Films'}</p>
            <p className="text-xl font-bold text-stone-100">{projects.length}</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0c0c10] border border-stone-800/80 shadow-lg flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-stone-400">{isAr ? 'اللقطات المنتجة' : 'Total Shots'}</p>
            <p className="text-xl font-bold text-stone-100">{totalShots}</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0c0c10] border border-stone-800/80 shadow-lg flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-stone-400">{isAr ? 'مدة العرض الإجمالية' : 'Total Runtime'}</p>
            <p className="text-xl font-bold text-stone-100">{totalSeconds}s ({Math.round(totalSeconds / 60)}m)</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0c0c10] border border-stone-800/80 shadow-lg flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-stone-400">{isAr ? 'التكلفة المقدرة' : 'Estimated Cost'}</p>
            <p className="text-xl font-bold text-emerald-400">${totalCost.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Projects Grid Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-bold text-stone-100 flex items-center gap-2">
            <Film className="w-5 h-5 text-amber-400" />
            <span>{isAr ? 'مكتبة الإنتاج السينمائي' : 'Cinema Film Vault'}</span>
            <span className="text-xs font-normal text-stone-400">({projects.length})</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((proj) => {
            const isCurrent = proj.id === currentProjectId;
            const shotsCount = proj.scenes.reduce((acc, sc) => acc + sc.shots.length, 0);
            const firstShotWithImage = proj.scenes.flatMap((s) => s.shots).find((sh) => sh.imageUrl);
            const posterUrl = firstShotWithImage?.imageUrl || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80';

            return (
              <div
                key={proj.id}
                className={`group relative rounded-xl overflow-hidden bg-[#0a0a0e] border transition-all duration-300 flex flex-col justify-between ${
                  isCurrent
                    ? 'border-amber-500 shadow-xl shadow-amber-500/10 ring-1 ring-amber-500/40'
                    : 'border-stone-800 hover:border-amber-500/40'
                }`}
              >
                {/* Poster & Header */}
                <div>
                  <div className="relative h-44 w-full overflow-hidden bg-stone-900">
                    <img
                      src={posterUrl}
                      alt={proj.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90 group-hover:brightness-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0e] via-transparent to-black/60" />

                    {/* Active badge */}
                    {isCurrent && (
                      <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-amber-500 text-stone-950 text-[11px] font-bold flex items-center gap-1 shadow-md">
                        <CheckCircle className="w-3 h-3" />
                        <span>{isAr ? 'الفيلم النشط' : 'Active Film'}</span>
                      </div>
                    )}

                    <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-xs text-stone-300">
                      <span className="px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm border border-stone-700 font-mono text-[11px]">
                        {proj.settings.aspectRatio} • {proj.settings.defaultResolution}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm border border-stone-700 text-[11px] text-amber-300">
                        {proj.settings.genre}
                      </span>
                    </div>
                  </div>

                  {/* Body Details */}
                  <div className="p-4 space-y-2">
                    <h3 className="text-base font-bold text-stone-100 group-hover:text-amber-300 transition-colors line-clamp-1">
                      {isAr ? proj.titleAr || proj.title : proj.title}
                    </h3>
                    <p className="text-xs text-stone-400 line-clamp-2 leading-relaxed">
                      {isAr ? proj.loglineAr || proj.synopsisAr || proj.synopsis : proj.logline || proj.synopsis}
                    </p>

                    <div className="pt-2 flex items-center gap-3 text-xs text-stone-400 border-t border-stone-800/80">
                      <span>{proj.scenes.length} {isAr ? 'مشاهد' : 'scenes'}</span>
                      <span>•</span>
                      <span>{shotsCount} {isAr ? 'لقطة' : 'shots'}</span>
                      <span>•</span>
                      <span>{proj.characters.length} {isAr ? 'شخصيات' : 'characters'}</span>
                    </div>
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className="p-3 bg-stone-950/80 border-t border-stone-800/80 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleExportJSON(proj)}
                      className="p-1.5 rounded hover:bg-stone-800 text-stone-400 hover:text-amber-300 transition"
                      title={isAr ? 'تصدير المشروع كملف JSON' : 'Export Project JSON'}
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDuplicateProject(proj.id)}
                      className="p-1.5 rounded hover:bg-stone-800 text-stone-400 hover:text-amber-300 transition"
                      title={isAr ? 'تكرار المشروع' : 'Duplicate Project'}
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    {projects.length > 1 && (
                      <button
                        onClick={() => {
                          if (confirm(isAr ? 'هل أنت متأكد من حذف هذا المشروع؟' : 'Delete this cinema project?')) {
                            onDeleteProject(proj.id);
                          }
                        }}
                        className="p-1.5 rounded hover:bg-rose-950/50 text-stone-400 hover:text-rose-400 transition"
                        title={isAr ? 'حذف المشروع' : 'Delete'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {!isCurrent ? (
                      <button
                        onClick={() => onSelectProject(proj.id)}
                        className="px-3 py-1.5 rounded text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 transition"
                      >
                        {isAr ? 'اختيار' : 'Select'}
                      </button>
                    ) : (
                      <button
                        onClick={() => onNavigateTab('auto_director')}
                        className="flex items-center gap-1 px-3 py-1.5 rounded text-xs font-bold bg-amber-500 hover:bg-amber-600 text-stone-950 transition shadow"
                      >
                        <span>{isAr ? 'فتح الاستوديو' : 'Open Studio'}</span>
                        {isAr ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* New Project Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0e0e13] border border-amber-500/30 rounded-2xl w-full max-w-xl p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>{isAr ? 'بدء إنتاج سينمائي جديد' : 'New Cinema Production'}</span>
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-stone-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {/* Quick Presets */}
            <div className="space-y-1.5">
              <label className="text-xs text-stone-400 font-medium">
                {isAr ? 'أو اختر قالب سينمائي جاهز:' : 'Or pick an inspiration template:'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setNewTitle(p.titleEn);
                      setNewTitleAr(p.titleAr);
                      setNewGenre(p.genre);
                      setNewSynopsis(p.synopsis);
                      setNewAspectRatio(p.aspectRatio);
                    }}
                    className="p-2 rounded-lg bg-stone-900/80 hover:bg-amber-500/10 border border-stone-800 hover:border-amber-500/40 text-left text-xs text-stone-300 transition"
                  >
                    <p className="font-bold text-amber-300 line-clamp-1">{isAr ? p.titleAr : p.titleEn}</p>
                    <p className="text-[10px] text-stone-500 line-clamp-1">{p.genre}</p>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'اسم الفيلم (بالإنجليزية):' : 'Film Title (English):'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Sands of Eternity"
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'اسم الفيلم (بالعربية):' : 'Film Title (Arabic):'}
                  </label>
                  <input
                    type="text"
                    value={newTitleAr}
                    onChange={(e) => setNewTitleAr(e.target.value)}
                    placeholder="مثال: رمال الخلود"
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'النوع / التصنيف:' : 'Genre:'}
                  </label>
                  <input
                    type="text"
                    value={newGenre}
                    onChange={(e) => setNewGenre(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'نسبة الشاشة:' : 'Aspect Ratio:'}
                  </label>
                  <select
                    value={newAspectRatio}
                    onChange={(e) => setNewAspectRatio(e.target.value as AspectRatio)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  >
                    <option value="2.39:1">2.39:1 (Cinemascope Panavision)</option>
                    <option value="16:9">16:9 (Standard Widescreen)</option>
                    <option value="9:16">9:16 (Vertical Cinema / Reels)</option>
                    <option value="4:3">4:3 (Vintage Academy)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-stone-300 font-medium">
                    {isAr ? 'الدقة الافتراضية:' : 'Resolution:'}
                  </label>
                  <select
                    value={newResolution}
                    onChange={(e) => setNewResolution(e.target.value as VideoResolution)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                  >
                    <option value="720p">720p (HD Fast)</option>
                    <option value="1080p">1080p (Full HD Master)</option>
                    <option value="2K">2K Cinema (DCI 2K)</option>
                    <option value="4K">4K Ultra HD</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-stone-300 font-medium">
                  {isAr ? 'قصة الفيلم / الملخص الأولي:' : 'Premise / Story Synopsis:'}
                </label>
                <textarea
                  rows={3}
                  value={newSynopsis}
                  onChange={(e) => setNewSynopsis(e.target.value)}
                  placeholder={
                    isAr
                      ? 'اكتب الفكرة أو قصة الفيلم ليقوم المخرج الآلي بتقسيمها إلى مشاهد ولقطات احترافية...'
                      : 'Describe the plot or premise to let Auto Director decompose it into shots...'
                  }
                  className="w-full px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-stone-400 hover:text-white hover:bg-stone-800 transition"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-md shadow-amber-500/20 transition"
                >
                  {isAr ? 'إنشاء وتوجيه' : 'Create Project'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
