/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Header & Master Navigation
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 * AI Assistant: ChatGPT (GT Assistant)
 */

import React from 'react';
import {
  Film,
  Sparkles,
  Sliders,
  Users,
  Layers,
  Cpu,
  Activity,
  Globe,
  CheckCircle2,
  Clapperboard,
  ShieldCheck,
} from 'lucide-react';
import { CinemaProject } from '../types/cinema';

export type ActiveTab =
  | 'dashboard'
  | 'auto_director'
  | 'manual_studio'
  | 'characters'
  | 'timeline'
  | 'engines'
  | 'diagnostics';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  lang: 'ar' | 'en';
  setLang: (lang: 'ar' | 'en') => void;
  project: CinemaProject;
  onOpenSmartDirector: () => void;
  smartDirectorScore?: number;
  isSaving?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  project,
  onOpenSmartDirector,
  smartDirectorScore,
  isSaving,
}) => {
  const isAr = lang === 'ar';

  const navItems: { id: ActiveTab; labelAr: string; labelEn: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', labelAr: 'المشاريع', labelEn: 'Projects', icon: <Film className="w-4 h-4" /> },
    { id: 'auto_director', labelAr: 'المخرج الآلي', labelEn: 'Auto Director', icon: <Sparkles className="w-4 h-4 text-amber-400" /> },
    { id: 'manual_studio', labelAr: 'استوديو اللقطات', labelEn: 'Shot Studio', icon: <Sliders className="w-4 h-4" /> },
    { id: 'characters', labelAr: 'تثبيت الشخصيات', labelEn: 'Characters', icon: <Users className="w-4 h-4" /> },
    { id: 'timeline', labelAr: 'المونتاج والتصدير', labelEn: 'Timeline & Render', icon: <Layers className="w-4 h-4 text-amber-400" /> },
    { id: 'engines', labelAr: 'المحركات والتكاليف', labelEn: 'AI Engines & Cost', icon: <Cpu className="w-4 h-4" /> },
    { id: 'diagnostics', labelAr: 'فحص النظام', labelEn: 'Diagnostics', icon: <Activity className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#070709]/95 backdrop-blur-md border-b border-amber-600/20 shadow-2xl">
      {/* Top Brand Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
        {/* Logo & Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-[#09090d] rounded-[7px] flex items-center justify-center">
              <Clapperboard className="w-5 h-5 text-amber-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-cinematic text-lg sm:text-xl font-bold tracking-wider bg-gradient-to-r from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
                AM CINEMA AI
              </span>
              <span className="hidden sm:inline-block text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                PRO STUDIO
              </span>
            </div>
            <p className="text-[11px] text-amber-500/70 font-medium tracking-tight">
              Create. Direct. Inspire.
            </p>
          </div>
        </div>

        {/* Project Context & Developer Credits */}
        <div className="hidden md:flex flex-col items-center text-center">
          <div className="flex items-center gap-2 text-xs text-stone-300">
            <span className="text-amber-400/80 font-medium">
              {isAr ? 'الفيلم الحالي:' : 'Current Film:'}
            </span>
            <span className="font-semibold text-stone-100 max-w-[200px] truncate">
              {isAr ? project.titleAr || project.title : project.title}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-900 border border-stone-700 text-stone-300">
              {project.settings.aspectRatio} | {project.settings.defaultResolution}
            </span>
          </div>
          <div className="text-[10px] text-stone-500 flex items-center gap-1.5 mt-0.5">
            <span className="text-amber-500 font-medium">AMMAR ALNAMI — عمار النمي</span>
            <span>•</span>
            <span>AI: ChatGPT (GT Assistant)</span>
          </div>
        </div>

        {/* Controls & Quick Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Smart Director Button */}
          <button
            onClick={onOpenSmartDirector}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-gradient-to-r from-amber-500/20 to-amber-600/10 hover:from-amber-500/30 hover:to-amber-600/20 text-amber-300 border border-amber-500/40 shadow-sm transition-all"
            title={isAr ? 'فتح المخرج الذكي لمراجعة الاستمرارية والتسلسل' : 'Smart AI Director Continuity Review'}
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">{isAr ? 'المخرج الذكي' : 'Smart Director'}</span>
            {smartDirectorScore !== undefined && (
              <span className="px-1.5 py-0.2 rounded bg-amber-500/30 text-amber-200 text-[10px] font-mono font-bold">
                {smartDirectorScore}%
              </span>
            )}
          </button>

          {/* Auto-save Status */}
          <div className="hidden lg:flex items-center gap-1 text-[11px] text-stone-400">
            <CheckCircle2 className={`w-3.5 h-3.5 ${isSaving ? 'text-amber-500 animate-spin' : 'text-emerald-400'}`} />
            <span>{isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'محفوظ تلقائياً' : 'Saved')}</span>
          </div>

          {/* Language Switch */}
          <button
            onClick={() => {
              const next = lang === 'ar' ? 'en' : 'ar';
              setLang(next);
              document.documentElement.dir = next === 'ar' ? 'rtl' : 'ltr';
              document.documentElement.lang = next;
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'ar' ? 'EN' : 'عربي'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="max-w-7xl mx-auto px-2 sm:px-6 flex items-center overflow-x-auto scrollbar-none border-t border-stone-800/60">
        <nav className="flex space-x-1 sm:space-x-2 py-1.5">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/10'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900/60'
                }`}
              >
                {item.icon}
                <span>{isAr ? item.labelAr : item.labelEn}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
