/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Multi-Provider AI Engines Hub & Cost Monitor
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Video,
  Image as ImageIcon,
  Mic,
  Smile,
  Film,
  DollarSign,
  ShieldCheck,
  Key,
  Check,
  AlertCircle,
  ExternalLink,
  Layers,
  RefreshCw,
} from 'lucide-react';
import { AIProviderConfig, CinemaProject } from '../types/cinema';
import { cinemaAudio } from '../utils/audioPlayer';

interface EnginesHubViewProps {
  project: CinemaProject;
  lang: 'ar' | 'en';
}

export const EnginesHubView: React.FC<EnginesHubViewProps> = ({ project, lang }) => {
  const isAr = lang === 'ar';
  const [providers, setProviders] = useState<AIProviderConfig[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeKeyModalProvider, setActiveKeyModalProvider] = useState<AIProviderConfig | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  const fetchProviders = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/providers');
      const data = await res.json();
      if (data.providers) {
        setProviders(data.providers);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProviders();
  }, []);

  const handleSaveKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeKeyModalProvider) return;

    try {
      const res = await fetch('/api/providers/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          providerId: activeKeyModalProvider.id,
          apiKey: apiKeyInput,
        }),
      });

      if (res.ok) {
        setSaveStatus(
          isAr
            ? 'تم حفظ المفتاح بأمان داخل الخادم (محمي من الواجهة الأمامية).'
            : 'Key securely stored on backend server.'
        );
        cinemaAudio.playCinematicSound('bell');
        fetchProviders();
        setTimeout(() => {
          setActiveKeyModalProvider(null);
          setApiKeyInput('');
          setSaveStatus(null);
        }, 1500);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to save key');
    }
  };

  const getEngineIcon = (type: string) => {
    switch (type) {
      case 'text_to_video':
      case 'image_to_video':
        return <Video className="w-4 h-4 text-amber-400" />;
      case 'text_to_image':
        return <ImageIcon className="w-4 h-4 text-amber-400" />;
      case 'voice':
        return <Mic className="w-4 h-4 text-amber-400" />;
      case 'lip_sync':
        return <Smile className="w-4 h-4 text-amber-400" />;
      default:
        return <Film className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'البنية متعددة المحركات (Multi-Provider Architecture)' : 'Pluggable AI Engine Architecture'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-amber-400" />
            <span>{isAr ? 'مركز محركات الذكاء الاصطناعي ومراقبة الرصيد والتكلفة' : 'AI Engines Hub & Cost Monitor'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1 max-w-3xl">
            {isAr
              ? 'يدعم النظام التبديل السلس بين المحركات المجانية (Pollinations) والمحركات المتقدمة (Gemini / Runway / Luma / Kling / ElevenLabs) دون إعادة بناء الكود، مع حماية تامة لمفاتيح API داخل الخادم.'
              : 'Seamlessly switch between zero-key free engines and high-end video/voice generators. All credentials stored exclusively server-side.'}
          </p>
        </div>

        <button
          onClick={fetchProviders}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-700 transition"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>{isAr ? 'تحديث حالة المحركات' : 'Refresh Engines'}</span>
        </button>
      </div>

      {/* Cost & Credit Monitor Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-gradient-to-br from-stone-950 to-[#0e0e14] border border-amber-500/30 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-stone-400">
            <span>{isAr ? 'استهلاك الفيلم الحالي' : 'Current Project Cost'}</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400 font-mono">
            ${(project.estimatedCostUsd || 0.0).toFixed(2)}
          </p>
          <p className="text-[11px] text-stone-400">
            {isAr ? 'توليد الصور والنصوص مجاني عبر باقة Free Tier.' : 'Text breakdown & Pollinations images at $0 cost.'}
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-gradient-to-br from-stone-950 to-[#0e0e14] border border-stone-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-stone-400">
            <span>{isAr ? 'المحركات النشطة' : 'Active Providers'}</span>
            <Cpu className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-300 font-mono">
            {providers.filter((p) => p.isConfigured || p.isFree).length} / {providers.length}
          </p>
          <p className="text-[11px] text-stone-400">
            {isAr ? 'جاهزة للتوليد الفوري دون توقف.' : 'Ready for zero-latency execution.'}
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-gradient-to-br from-stone-950 to-[#0e0e14] border border-stone-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-stone-400">
            <span>{isAr ? 'معايير الأمان والتشفير' : 'Vault Security'}</span>
            <ShieldCheck className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-sm font-bold text-stone-100 flex items-center gap-1.5 pt-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>{isAr ? 'مفاتيح API معزولة داخل الخادم' : 'Server-Side Vault Protected'}</span>
          </p>
          <p className="text-[11px] text-stone-400">
            {isAr ? 'لا يتم إرسال أي مفتاح خارجي إلى متصفح العميل.' : 'Never exposed to frontend client bundles.'}
          </p>
        </div>
      </div>

      {/* Engines Grid */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-stone-200">
          {isAr ? 'المحركات المتوفرة وروابط الربط:' : 'Registered AI Generation Engines:'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {providers.map((prov) => (
            <div
              key={prov.id}
              className={`p-5 rounded-xl bg-[#0b0b10] border transition-all flex flex-col justify-between ${
                prov.isConfigured || prov.isFree
                  ? 'border-stone-800 hover:border-amber-500/40'
                  : 'border-stone-900 opacity-75'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-stone-900 border border-stone-800">
                      {getEngineIcon(prov.type)}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{prov.name}</h4>
                      <span className="text-[10px] uppercase font-mono text-stone-400">
                        {prov.type.replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>

                  {prov.isFree ? (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                      {isAr ? 'مجاني / مفتوح' : 'FREE TIER'}
                    </span>
                  ) : prov.isConfigured ? (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                      {isAr ? 'متصل' : 'ACTIVE'}
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-stone-800 text-stone-400 text-[10px]">
                      {isAr ? 'يتطلب مفتاح' : 'NO KEY'}
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-400 leading-relaxed">
                  {isAr ? prov.descriptionAr : prov.description}
                </p>

                <div className="p-2.5 rounded-lg bg-stone-950/80 border border-stone-800 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-stone-400">
                    <span>{isAr ? 'التكلفة التقديرية:' : 'Cost Estimate:'}</span>
                    <span className="text-amber-300 font-mono font-medium">{prov.costPerUnit}</span>
                  </div>
                  <div className="flex items-center justify-between text-stone-400">
                    <span>{isAr ? 'زمن الاستجابة المتوقع:' : 'Latency:'}</span>
                    <span className="text-stone-300 font-mono">{prov.estimatedLatency}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 mt-3 border-t border-stone-800 flex items-center justify-between">
                {prov.isFree ? (
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>{isAr ? 'مفعّل تلقائياً بدون إعدادات' : 'Zero Config Ready'}</span>
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      setActiveKeyModalProvider(prov);
                      setApiKeyInput('');
                      setSaveStatus(null);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-amber-300 border border-stone-700 transition"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>
                      {prov.isConfigured
                        ? isAr ? 'تعديل المفتاح' : 'Update Key'
                        : isAr ? 'ربط مفتاح API' : 'Connect Key'}
                    </span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Key Configuration Modal */}
      {activeKeyModalProvider && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0e0e13] border border-amber-500/40 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="text-base font-bold text-amber-300 flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>
                  {isAr ? `ربط مفتاح ${activeKeyModalProvider.name}` : `Connect ${activeKeyModalProvider.name}`}
                </span>
              </h3>
              <button
                onClick={() => setActiveKeyModalProvider(null)}
                className="text-stone-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveKey} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-stone-300 font-medium">
                  {isAr ? 'مفتاح API السري الخاص بك:' : 'Provider API Secret Key:'}
                </label>
                <input
                  type="password"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="sk-..."
                  className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-800 focus:border-amber-500 text-stone-100 text-xs font-mono outline-none"
                />
                <p className="text-[10px] text-stone-500">
                  {isAr
                    ? 'يتم تخزين هذا المفتاح حصرياً في خادم Express ولا يظهر مطلقاً في المتصفح.'
                    : 'Stored in server memory only; strictly protected from client exposure.'}
                </p>
              </div>

              {saveStatus && (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{saveStatus}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-2 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setActiveKeyModalProvider(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-stone-400 hover:text-white"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-md shadow-amber-500/20"
                >
                  {isAr ? 'حفظ المفتاح بأمان' : 'Save Key'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
