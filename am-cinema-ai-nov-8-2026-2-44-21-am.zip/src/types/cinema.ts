/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AM CINEMA AI — Types & Data Contracts
 * Lead Developer: AMMAR ALNAMI (عمار النمي)
 */

export type CameraMovementType = 
  | 'zoom_in'
  | 'zoom_out'
  | 'pan_left'
  | 'pan_right'
  | 'tilt_up'
  | 'tilt_down'
  | 'camera_tracking'
  | 'orbit_360'
  | 'crane_shot'
  | 'static_tripod';

export type ShotFramingType = 
  | 'extreme_wide'
  | 'wide'
  | 'medium_shot'
  | 'close_up'
  | 'extreme_close_up'
  | 'over_the_shoulder'
  | 'low_angle'
  | 'high_angle'
  | 'dutch_angle';

export type VideoResolution = '360p' | '480p' | '720p' | '1080p' | '2K' | '4K';

export type AspectRatio = '16:9' | '2.39:1' | '9:16' | '4:3' | '1:1';

export type TransitionType = 'cut' | 'crossfade' | 'fade_black' | 'dissolve' | 'whip_pan';

export interface Character {
  id: string;
  name: string;
  nameAr: string;
  role: string; // e.g. 'Protagonist', 'Antagonist', 'Mentor'
  age: number | string;
  gender: string;
  ethnicityOrStyle: string;
  facialFeatures: string; // e.g. 'piercing hazel eyes, sharp cheekbones, subtle scar over left eyebrow'
  wardrobe: string; // e.g. 'distressed charcoal leather jacket with bronze zipper, dark tailored trousers'
  signatureColors: string[]; // e.g. ['#b45309', '#1e293b']
  accessories: string; // e.g. 'vintage brass watch, obsidian ring'
  referenceImageUrl?: string;
  consistencyPromptToken: string; // Injected into prompts for continuity
  createdAt: number;
}

export interface DialogueLine {
  id: string;
  characterId?: string;
  speakerName: string;
  text: string;
  textAr: string;
  emotion: 'dramatic' | 'whisper' | 'angry' | 'joyful' | 'tense' | 'neutral';
  audioUrl?: string;
  durationSeconds: number;
}

export interface Shot {
  id: string;
  sceneId: string;
  shotNumber: number;
  title: string;
  titleAr: string;
  framing: ShotFramingType;
  cameraMovement: CameraMovementType;
  focalLength: '24mm' | '35mm' | '50mm' | '85mm' | '135mm';
  motionStrength: number; // 1 to 10
  durationSeconds: number; // 2 to 15s
  resolution: VideoResolution;
  visualPrompt: string;
  visualPromptAr: string;
  negativePrompt?: string;
  characterIds: string[];
  imageUrl?: string;
  videoUrl?: string;
  isGenerating?: boolean;
  generationProgress?: number;
  generationError?: string;
  providerUsed?: string;
  lightingStyle: string;
  dialogue?: DialogueLine;
  ambientSound?: string;
  musicIntensity: 'quiet' | 'building' | 'climax' | 'calm' | 'suspense';
  transitionToNext: TransitionType;
}

export interface Scene {
  id: string;
  sceneNumber: number;
  title: string;
  titleAr: string;
  location: string;
  locationAr: string;
  timeOfDay: 'dawn' | 'day' | 'golden_hour' | 'dusk' | 'night' | 'midnight';
  weatherOrAtmosphere: string;
  dramaticBeat: string;
  shots: Shot[];
}

export interface ProjectSettings {
  aspectRatio: AspectRatio;
  defaultResolution: VideoResolution;
  targetDurationSeconds: number; // e.g. 120s
  genre: string;
  visualStyle: string; // e.g. 'Cinematic Neo-Noir 35mm Film Grain', 'Cyberpunk Gold & Shadow', 'Epic Historical Panavision'
  filmColorPalette: string[];
}

export interface CinemaProject {
  id: string;
  title: string;
  titleAr: string;
  logline: string;
  loglineAr: string;
  synopsis: string;
  synopsisAr: string;
  owner: string; // 'AMMAR ALNAMI'
  settings: ProjectSettings;
  characters: Character[];
  scenes: Scene[];
  audioTrack?: {
    musicStyle: string;
    musicUrl?: string;
    volume: number; // 0 to 1
  };
  totalDurationSeconds: number;
  estimatedCostUsd: number;
  createdAt: number;
  updatedAt: number;
}

export interface SmartDirectorContinuityIssue {
  id: string;
  type: 'character' | 'lighting' | 'pacing' | 'camera' | 'audio';
  severity: 'warning' | 'critical' | 'suggestion';
  messageAr: string;
  messageEn: string;
  shotId?: string;
  sceneNumber?: number;
  shotNumber?: number;
  recommendationAr: string;
  recommendationEn: string;
  autoFixPrompt?: string;
}

export interface SmartDirectorReport {
  overallScore: number; // 0 - 100
  pacingRating: string;
  visualContinuityRating: string;
  issues: SmartDirectorContinuityIssue[];
  directorNotesAr: string;
  directorNotesEn: string;
  timestamp: number;
}

export interface AIProviderConfig {
  id: string;
  name: string;
  type: 'text_to_video' | 'image_to_video' | 'text_to_image' | 'voice' | 'lip_sync';
  isConfigured: boolean;
  isFree: boolean;
  costPerUnit: string;
  estimatedLatency: string;
  description: string;
  descriptionAr: string;
}

export interface GenerationJob {
  id: string;
  shotId: string;
  type: 'image' | 'video' | 'voice';
  provider: string;
  status: 'queued' | 'rendering' | 'completed' | 'failed';
  progress: number;
  error?: string;
  outputUrl?: string;
  startedAt: number;
  completedAt?: number;
  costUsd: number;
}
